# VIBE TALK 🎙️✨
> **Connect. Talk. Make Friends.**  
> A modern, mobile-first social voice chat and global language exchange application inspired by YeeTalk.

---

## 🌟 Features Overview

1. **Authentication**
   - Seamless Firebase Authentication support for real email/password and Google login.
   - Fast Instant Guest login mode for instant preview and evaluation without mandatory credential setup.
   - Client and server-side input protection and state synchronization.

2. **User Profiles & Social Connections**
   - Unique usernames, custom bios, flag & country indicators, native and learning languages.
   - Reputation score, follower/following counts, and a 3-second audio voice bio snippet.
   - Add/remove friends, accept/decline friend requests, and direct user blocking.

3. **Home & Global Discovery**
   - Featured active voice stages with real-time speaker indicators.
   - Filter rooms and users by language (Japanese, Spanish, Korean, French, German, Arabic, English, etc.) and topics (Language Exchange, Music & Chill, Late Night Vibes, Tech & Startups, Gaming, Deep Talks).

4. **Live Voice Rooms & Audio Stages**
   - Visual audio stage with host crown, speaker avatars, and listener grid.
   - Live microphone capture with browser HTML5 Web Audio API & AnalyserNode for real-time pulsing audio rings.
   - Hand-raising system: listeners can request to speak, and hosts can accept or decline.
   - Host moderation tools: mute participant, promote to speaker, demote to listener, kick from room, or close room.
   - Soundboard effects: synthesized applause, party cheer, chime, and mic clicks.
   - Floating animated emoji reactions (`❤️`, `🔥`, `👏`, `😂`, `💎`, `🚀`, `🎙️`) and confetti party.
   - In-room live chat drawer.
   - Background mini-player bar when minimizing the room to browse messages or discovery tabs.

5. **Direct Messaging**
   - 1-on-1 conversations with unread notification badges.
   - Image attachment previews, emoji support, typing indicators, and simulated reply flow.
   - Direct reporting and blocking actions directly from the chat header.

6. **Safety & Moderation Portal (Admin Dashboard)**
   - Dedicated Admin Moderation Portal for incident reviews.
   - Actions to issue official warnings, apply 24-hour audio mutes, or ban disruptive users.
   - Audit trail of recent safety actions.

7. **Android & Google Play Store Export**
   - Built-in Capacitor instructions and AndroidManifest.xml permissions configuration for packaging to APK or Android App Bundle (AAB).

---

## 🚀 Environment Variables

Copy `.env.example` to `.env` and fill in optional production credentials:

```bash
# Firebase Production Configuration (Optional - falls back to Local Demo Mode automatically)
VITE_FIREBASE_API_KEY="your-api-key"
VITE_FIREBASE_AUTH_DOMAIN="your-project.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="your-project-id"
VITE_FIREBASE_STORAGE_BUCKET="your-project.appspot.com"
VITE_FIREBASE_MESSAGING_SENDER_ID="your-sender-id"
VITE_FIREBASE_APP_ID="your-app-id"

# LiveKit WebRTC Configuration (Optional - falls back to Web Audio Mesh automatically)
VITE_LIVEKIT_URL="wss://your-livekit-server.com"
```

---

## 📱 Exporting for Android & Google Play Store

### 1. Initialize Capacitor
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "VIBE TALK" "com.vibetalk.app" --web-dir dist
npm run build
npx cap add android
npx cap sync android
```

### 2. Configure Android Permissions
In `android/app/src/main/AndroidManifest.xml`, add the following permissions inside `<manifest>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-feature android:name="android.hardware.microphone" android:required="true" />
```

### 3. Build & Sign Release Bundle
```bash
npx cap open android
# Build release bundle
cd android && ./gradlew bundleRelease
```

---

## 🛠️ Tech Stack
- **Framework:** React 19, TypeScript
- **Styling:** Tailwind CSS v4, dark navy palette (`#070b14`), neon purple & cyan gradients
- **Icons & Motion:** Lucide React, Canvas Confetti
- **Audio Engine:** Web Audio API (real mic analyzer, synthesized SFX soundboard, audio visualizer)
- **State Management:** React Context API with LocalStorage persistence and Firebase SDK bridge
