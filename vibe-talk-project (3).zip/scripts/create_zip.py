import os
import zipfile

def create_project_zip():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    output_zip_path = os.path.join(base_dir, 'public', 'vibe-talk-project.zip')
    
    # Ensure public folder exists
    os.makedirs(os.path.dirname(output_zip_path), exist_ok=True)
    
    # Exclude directories
    exclude_dirs = {
        'node_modules',
        'dist',
        'dev-dist',
        '.git',
        '.gradle',
        'build',
        'captures',
        '.idea',
        '__pycache__'
    }
    
    # Exclude files
    exclude_files = {
        'vibe-talk-project.zip',
        'local.properties',
        '.env',
        '.env.local'
    }

    print(f"Creating project ZIP at: {output_zip_path}")
    count = 0
    with zipfile.ZipFile(output_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            # Exclude unwanted directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            # Skip if inside an excluded directory path
            rel_root = os.path.relpath(root, base_dir)
            if any(part in exclude_dirs for part in rel_root.split(os.sep)):
                continue

            for file in files:
                if file in exclude_files or file.endswith('.iml') or file.endswith('.pyc'):
                    continue
                if file.startswith('.env') and file != '.env.example':
                    continue

                full_path = os.path.join(root, file)
                archive_name = os.path.relpath(full_path, base_dir)
                
                # Double check not adding the output zip itself
                if archive_name == os.path.join('public', 'vibe-talk-project.zip'):
                    continue
                
                zipf.write(full_path, archive_name)
                count += 1

    file_size_mb = os.path.getsize(output_zip_path) / (1024 * 1024)
    print(f"Successfully zipped {count} files. Total size: {file_size_mb:.2f} MB")

if __name__ == '__main__':
    create_project_zip()
