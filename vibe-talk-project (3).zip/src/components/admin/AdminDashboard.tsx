import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, X, AlertTriangle, CheckCircle, Ban, VolumeX, Eye } from 'lucide-react';
import { ModerationReport } from '../../types';

export const AdminDashboard: React.FC = () => {
  const {
    showAdminDashboard,
    setShowAdminDashboard,
    reports,
    resolveReport,
    dismissReport,
    blockUser,
    openUserProfile,
  } = useApp();

  const [filter, setFilter] = useState<'all' | 'pending' | 'actioned'>('all');
  const [auditLog, setAuditLog] = useState<{ id: string; action: string; time: string }[]>([
    {
      id: 'log_1',
      action: 'Automated filter blocked spam link in "Tokyo Chill"',
      time: '12m ago',
    },
    {
      id: 'log_2',
      action: 'Admin issued audio warning to disruptive speaker',
      time: '1h ago',
    },
  ]);

  if (!showAdminDashboard) return null;

  const filteredReports = reports.filter((r) => {
    if (filter === 'pending') return r.status === 'pending';
    if (filter === 'actioned') return r.status !== 'pending';
    return true;
  });

  const handleAction = (report: ModerationReport, actionType: 'warn' | 'mute' | 'ban' | 'dismiss') => {
    let actionText = '';
    if (actionType === 'warn') {
      actionText = `Official warning issued to @${report.reportedUser.username}`;
    } else if (actionType === 'mute') {
      actionText = `24-hour room audio mute applied to @${report.reportedUser.username}`;
    } else if (actionType === 'ban') {
      actionText = `Account permanently suspended: @${report.reportedUser.username}`;
      blockUser(report.reportedUserId);
    } else {
      actionText = 'Report dismissed after audit';
      dismissReport(report.id);
      return;
    }

    resolveReport(report.id, actionText);
    setAuditLog((prev) => [
      {
        id: `log_${Date.now()}`,
        action: actionText,
        time: 'Just now',
      },
      ...prev,
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-slate-900 border border-purple-900/50 rounded-3xl p-6 shadow-2xl max-h-[90vh] flex flex-col">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-950/80 border border-purple-800 text-purple-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-display">
                Admin & Safety Moderation Portal
              </h2>
              <p className="text-xs text-slate-400">
                Review incidents, enforce voice guidelines & maintain platform integrity
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowAdminDashboard(false)}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center justify-between py-3 shrink-0">
          <div className="flex items-center gap-2">
            {(['all', 'pending', 'actioned'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-colors ${
                  filter === tab
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {tab} ({tab === 'all' ? reports.length : reports.filter((r) => tab === 'pending' ? r.status === 'pending' : r.status !== 'pending').length})
              </button>
            ))}
          </div>

          <span className="text-xs text-purple-400 font-medium">Role: Verified Administrator</span>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {filteredReports.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-slate-800 rounded-2xl">
              <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <p className="text-xs text-slate-400">All reports are clear and resolved!</p>
            </div>
          ) : (
            filteredReports.map((report) => (
              <div
                key={report.id}
                className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={report.reportedUser.avatar}
                      alt={report.reportedUser.displayName}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-white">
                          {report.reportedUser.displayName}
                        </h4>
                        <span className="text-[10px] text-slate-400">
                          @{report.reportedUser.username}
                        </span>
                      </div>
                      <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-semibold bg-red-950/60 text-red-300 border border-red-800/40">
                        {report.reason}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                      report.status === 'pending'
                        ? 'bg-amber-950/60 text-amber-300 border border-amber-800/40'
                        : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40'
                    }`}
                  >
                    {report.status}
                  </span>
                </div>

                <div className="bg-slate-900/90 rounded-xl p-2.5 text-xs text-slate-300">
                  <p>
                    <strong className="text-slate-400">Reporter:</strong>{' '}
                    {report.reporterUser.displayName} (@{report.reporterUser.username})
                  </p>
                  {report.roomTitle && (
                    <p className="mt-1">
                      <strong className="text-slate-400">Context Room:</strong> {report.roomTitle}
                    </p>
                  )}
                  <p className="mt-1 text-slate-200">
                    <strong className="text-slate-400">Notes:</strong> "{report.notes}"
                  </p>
                  {report.actionTaken && (
                    <p className="mt-1.5 text-purple-300 font-medium">
                      ✓ Resolution: {report.actionTaken}
                    </p>
                  )}
                </div>

                {report.status === 'pending' && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      onClick={() => handleAction(report, 'warn')}
                      className="px-2.5 py-1.5 rounded-xl bg-amber-600/80 hover:bg-amber-600 text-white text-xs font-medium flex items-center gap-1"
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>Issue Warning</span>
                    </button>
                    <button
                      onClick={() => handleAction(report, 'mute')}
                      className="px-2.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-medium flex items-center gap-1"
                    >
                      <VolumeX className="w-3.5 h-3.5" />
                      <span>Mute 24h</span>
                    </button>
                    <button
                      onClick={() => handleAction(report, 'ban')}
                      className="px-2.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-medium flex items-center gap-1"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>Ban User</span>
                    </button>
                    <button
                      onClick={() => handleAction(report, 'dismiss')}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs ml-auto"
                    >
                      Dismiss
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Audit Log Strip */}
        <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400 shrink-0">
          <p className="font-semibold text-slate-300 mb-1.5">Recent Moderation Audit Trail</p>
          <div className="space-y-1">
            {auditLog.slice(0, 2).map((log) => (
              <div key={log.id} className="flex items-center justify-between text-[11px]">
                <span className="truncate max-w-[400px] text-slate-300">• {log.action}</span>
                <span className="text-slate-500 shrink-0">{log.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
