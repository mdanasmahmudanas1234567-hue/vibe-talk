import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Smartphone,
  X,
  Copy,
  Check,
  Download,
  Code,
  Globe,
  Terminal,
  ExternalLink,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const AndroidExportGuide: React.FC = () => {
  const { showAndroidGuide, setShowAndroidGuide } = useApp();
  const { isInstallable, isInstalled, install } = usePWAInstall();

  const [activeTab, setActiveTab] = useState<'phone_apk' | 'capacitor' | 'source_code'>('phone_apk');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!showAndroidGuide) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const appLiveUrl = window.location.origin;

  const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.vibetalk.app">

    <!-- Essential Voice Room & Microphone Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-feature android:name="android.hardware.microphone" android:required="true" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="VIBE TALK"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">

        <activity
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:name=".MainActivity"
            android:label="VIBE TALK"
            android:theme="@style/AppTheme.NoActionBarLaunch"
            android:launchMode="singleTask"
            android:exported="true">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const termuxCommands = `# 1. Install Termux from F-Droid on your Android phone
# 2. Run these commands inside Termux on your phone:
pkg update && pkg install nodejs-lts git openjdk-17 -y
npm install -g @bubblewrap/cli

# 3. Generate Android APK for VIBE TALK:
bubblewrap init --manifest="${appLiveUrl}/manifest.webmanifest"
bubblewrap build

# The output APK will be saved in:
# app-release-signed.apk -> Tap to install on your phone!`;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-slate-900 border border-purple-900/50 rounded-3xl p-5 sm:p-6 shadow-2xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950/80 border border-cyan-800 text-cyan-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-display">
                Android APK & Packaging Hub
              </h2>
              <p className="text-xs text-slate-400">
                Architecture overview and phone-only APK generation
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowAndroidGuide(false)}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Direct Project ZIP Download Banner */}
        <div className="mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-purple-900/50 via-indigo-900/50 to-cyan-950/50 border border-purple-500/40 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shrink-0">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 font-display">
                <Download className="w-4 h-4 text-cyan-400" />
                <span>Complete VIBE TALK Project ZIP (1.05 MB)</span>
              </h3>
            </div>
            <p className="text-[11px] text-purple-200/90 mt-0.5">
              Includes full source code, native <code className="text-cyan-300 font-mono">android/</code> project, Gradle configs, and <code className="text-cyan-300 font-mono">build-apk.yml</code>. Clean archive with zero secrets or node_modules.
            </p>
          </div>
          <a
            href="/vibe-talk-project.zip"
            download="vibe-talk-project.zip"
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-cyan-950/50 flex items-center gap-2 shrink-0 transition-all active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download ZIP</span>
          </a>
        </div>

        {/* Web App vs Native App Answer Banner */}
        <div className="mt-3 p-3 rounded-2xl bg-gradient-to-r from-purple-950/70 via-indigo-950/60 to-slate-950/80 border border-purple-800/40 text-xs shrink-0">
          <div className="flex items-center gap-1.5 font-bold text-purple-200 mb-1">
            <Globe className="w-4 h-4 text-cyan-400" />
            <span>Is this a Web App or Native Android App?</span>
          </div>
          <p className="text-slate-300 leading-relaxed text-[11px] sm:text-xs">
            This project is a <strong>modern Progressive Web Application (React 19 + TypeScript + Vite)</strong> with a mobile-first native UI. It runs directly in phone web browsers, <strong>can be installed with 1 tap as an app icon on your Android home screen</strong>, and can be converted into an installable <strong>Android APK file</strong> using the cloud or phone tools below.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-1.5 py-3 border-b border-slate-800 shrink-0 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('phone_apk')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'phone_apk'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            📱 Build APK on Phone
          </button>
          <button
            onClick={() => setActiveTab('capacitor')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'capacitor'
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            ⚡ Capacitor / Android Studio
          </button>
          <button
            onClick={() => setActiveTab('source_code')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'source_code'
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            📜 AndroidManifest & Configs
          </button>
        </div>

        {/* Tab 1: Phone-Only APK Generation */}
        {activeTab === 'phone_apk' && (
          <div className="flex-1 overflow-y-auto space-y-4 py-3 pr-1 text-xs">
            {/* Quick 1-tap browser install if available */}
            {isInstallable && !isInstalled && (
              <div className="bg-emerald-950/50 border border-emerald-800/40 rounded-2xl p-3.5 flex items-center justify-between gap-3">
                <div>
                  <h4 className="font-bold text-white text-xs flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>Instant Install to Home Screen</span>
                  </h4>
                  <p className="text-[11px] text-emerald-200/80 mt-0.5">
                    Install VIBE TALK directly on your Android phone without needing an APK.
                  </p>
                </div>
                <button
                  onClick={install}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md shrink-0"
                >
                  Install Now
                </button>
              </div>
            )}

            {/* Method 1: Cloud APK with PWABuilder */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-sm flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-600 text-white flex items-center justify-center text-[10px]">1</span>
                  <span>Method A: Online Cloud APK (Zero PC, 2 Minutes)</span>
                </span>
                <span className="text-[10px] text-cyan-300 bg-cyan-950/60 border border-cyan-800 px-2 py-0.5 rounded-full">
                  Recommended
                </span>
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                You can generate a signed, installable Android APK right from your phone browser using Microsoft's free official PWABuilder tool:
              </p>
              <ol className="space-y-1.5 text-[11px] text-slate-300 list-decimal list-inside pl-1">
                <li>
                  Open Chrome on your phone and go to{' '}
                  <a
                    href="https://www.pwabuilder.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 underline font-semibold inline-flex items-center gap-0.5"
                  >
                    pwabuilder.com <ExternalLink className="w-3 h-3" />
                  </a>
                </li>
                <li>
                  Paste your app URL:
                  <div className="flex items-center gap-2 mt-1 bg-slate-900 border border-purple-900/40 rounded-xl p-2 font-mono text-[11px] text-purple-300">
                    <span className="truncate flex-1">{appLiveUrl}</span>
                    <button
                      onClick={() => handleCopy(appLiveUrl, 'url')}
                      className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 shrink-0"
                    >
                      {copiedKey === 'url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </li>
                <li>Tap <strong>"Start"</strong>. PWABuilder will test your icons & manifest (already 100% configured!).</li>
                <li>Tap <strong>"Package for Stores"</strong> &rarr; select <strong>"Android"</strong>.</li>
                <li>Click <strong>"Generate APK"</strong>. The APK downloads directly into your phone's <em>Downloads</em> folder.</li>
                <li>Tap the downloaded file to install VIBE TALK on your phone!</li>
              </ol>
            </div>

            {/* Method 2: Termux command-line on phone */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-2">
              <span className="font-bold text-white text-sm flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-[10px]">2</span>
                <span>Method B: Termux Terminal (On Android Phone)</span>
              </span>
              <p className="text-slate-300 text-xs">
                If you have Termux installed on your Android device, you can build the APK locally using Bubblewrap CLI:
              </p>
              <div className="relative bg-slate-900 border border-purple-900/30 rounded-xl p-3 font-mono text-[11px] text-cyan-300 overflow-x-auto">
                <button
                  onClick={() => handleCopy(termuxCommands, 'termux')}
                  className="absolute top-2.5 right-2.5 p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  {copiedKey === 'termux' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <pre>{termuxCommands}</pre>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Capacitor & Android Studio */}
        {activeTab === 'capacitor' && (
          <div className="flex-1 overflow-y-auto space-y-4 py-3 pr-1 text-xs">
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-2">
              <h3 className="font-bold text-white text-sm">Capacitor Full Android Build</h3>
              <p className="text-slate-300 text-xs leading-relaxed">
                To build with Capacitor locally or inside a cloud shell:
              </p>
              <div className="relative bg-slate-900 border border-purple-900/30 rounded-xl p-3 font-mono text-[11px] text-cyan-300 overflow-x-auto">
                <button
                  onClick={() =>
                    handleCopy(
                      `npm install @capacitor/core @capacitor/cli @capacitor/android
npm run build
npx cap add android
npx cap sync android
npx cap open android`,
                      'cap_cmds'
                    )
                  }
                  className="absolute top-2.5 right-2.5 p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  {copiedKey === 'cap_cmds' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <pre>{`npm install @capacitor/core @capacitor/cli @capacitor/android
npm run build
npx cap add android
npx cap sync android
npx cap open android`}</pre>
              </div>
            </div>

            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-2">
              <h4 className="font-bold text-white text-xs">Play Store Release Build (Command Line)</h4>
              <div className="relative bg-slate-900 border border-purple-900/30 rounded-xl p-3 font-mono text-[11px] text-purple-300 overflow-x-auto">
                <button
                  onClick={() =>
                    handleCopy(
                      `cd android
# Build release APK
./gradlew assembleRelease

# Or build Google Play App Bundle (.aab)
./gradlew bundleRelease`,
                      'gradle_cmds'
                    )
                  }
                  className="absolute top-2.5 right-2.5 p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  {copiedKey === 'gradle_cmds' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <pre>{`cd android
# Build release APK
./gradlew assembleRelease

# Or build Google Play App Bundle (.aab)
./gradlew bundleRelease`}</pre>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Complete Source Code & AndroidManifest */}
        {activeTab === 'source_code' && (
          <div className="flex-1 overflow-y-auto space-y-4 py-3 pr-1 text-xs">
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-xs">android/app/src/main/AndroidManifest.xml</h4>
                <button
                  onClick={() => handleCopy(androidManifestXml, 'manifest')}
                  className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-xs flex items-center gap-1"
                >
                  {copiedKey === 'manifest' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy XML</span>
                </button>
              </div>
              <div className="bg-slate-900 border border-purple-900/30 rounded-xl p-3 font-mono text-[10px] text-cyan-300 overflow-x-auto max-h-56">
                <pre>{androidManifestXml}</pre>
              </div>
            </div>

            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-xs">capacitor.config.json</h4>
                <button
                  onClick={() =>
                    handleCopy(
                      `{
  "appId": "com.vibetalk.app",
  "appName": "VIBE TALK",
  "webDir": "dist",
  "bundledWebRuntime": false,
  "server": {
    "androidScheme": "https"
  }
}`,
                      'cap_json'
                    )
                  }
                  className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-xs flex items-center gap-1"
                >
                  {copiedKey === 'cap_json' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy JSON</span>
                </button>
              </div>
              <div className="bg-slate-900 border border-purple-900/30 rounded-xl p-3 font-mono text-[10px] text-purple-300">
                <pre>{`{
  "appId": "com.vibetalk.app",
  "appName": "VIBE TALK",
  "webDir": "dist",
  "bundledWebRuntime": false,
  "server": {
    "androidScheme": "https"
  }
}`}</pre>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>PWA & TWA Manifests Validated (Android 14+ Ready)</span>
          </div>
          <button
            onClick={() => setShowAndroidGuide(false)}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
