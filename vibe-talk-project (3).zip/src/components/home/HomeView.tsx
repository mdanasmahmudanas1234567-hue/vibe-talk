import React from 'react';
import { useApp } from '../../context/AppContext';
import { Radio, Users, Sparkles, MessageCircle, Volume2, Globe, Plus, Flame } from 'lucide-react';
import { VoiceRoom } from '../../types';

export const HomeView: React.FC = () => {
  const {
    rooms,
    users,
    joinRoom,
    setShowCreateRoomModal,
    openUserProfile,
    openChatWithUser,
    setCurrentTab,
  } = useApp();

  const featuredRooms = rooms.slice(0, 3);
  const activeUsers = users.slice(0, 4);

  return (
    <div className="space-y-6 pb-24 pt-2">
      {/* Hero Welcome Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-900/40 via-indigo-950/40 to-slate-900 border border-purple-500/20 p-5 sm:p-6 shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-48 h-48 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-lg">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Connect · Talk · Make Friends</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display leading-tight">
            Drop into global voice rooms & speak your vibe.
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            Practice new languages with native speakers, chill to lo-fi beats, and make genuine international friends in real-time audio stages.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-4">
            <button
              onClick={() => setShowCreateRoomModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:opacity-90 text-white font-semibold text-xs shadow-lg shadow-purple-900/30 transition-transform active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Create Voice Room</span>
            </button>

            <button
              onClick={() => setCurrentTab('discover')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/60 text-slate-200 font-medium text-xs transition-colors"
            >
              <Globe className="w-4 h-4 text-cyan-400" />
              <span>Explore Languages</span>
            </button>
          </div>
        </div>
      </div>

      {/* Featured Live Rooms */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-pink-500" />
            <h2 className="text-base font-bold text-white font-display">Featured Live Rooms</h2>
          </div>
          <button
            onClick={() => setCurrentTab('rooms')}
            className="text-xs text-purple-400 hover:text-purple-300 font-medium"
          >
            View all ({rooms.length})
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {featuredRooms.map((room) => {
            const speakers = room.participants.filter(
              (p) => p.role === 'host' || p.role === 'speaker'
            );
            const isSpeakingNow = room.participants.some((p) => p.isSpeaking);

            return (
              <div
                key={room.id}
                onClick={() => joinRoom(room)}
                className="group relative bg-slate-900/70 hover:bg-slate-900/90 border border-slate-800 hover:border-purple-500/40 rounded-2xl p-4 transition-all duration-200 cursor-pointer shadow-lg hover:shadow-purple-950/30 flex flex-col justify-between"
              >
                <div>
                  {/* Top Bar: Topic & Live indicator */}
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[11px] font-semibold text-purple-300 bg-purple-950/60 px-2.5 py-0.5 rounded-md border border-purple-800/40">
                      {room.topic}
                    </span>
                    <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-medium">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span>{room.totalParticipantsCount} active</span>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-sm font-bold text-white group-hover:text-purple-200 transition-colors line-clamp-2">
                    {room.title}
                  </h3>

                  <p className="text-xs text-slate-400 mt-1 line-clamp-1">
                    {room.description}
                  </p>

                  {/* Speakers preview circles */}
                  <div className="flex items-center gap-3 mt-4 pt-3 border-t border-slate-800/80">
                    <div className="flex -space-x-2">
                      {speakers.slice(0, 3).map((speaker) => (
                        <img
                          key={speaker.user.id}
                          src={speaker.user.avatar}
                          alt={speaker.user.displayName}
                          className="w-7 h-7 rounded-full object-cover border-2 border-slate-900 bg-slate-800"
                          referrerPolicy="no-referrer"
                        />
                      ))}
                    </div>
                    <div className="text-[11px] text-slate-300">
                      <span>Host: <strong className="text-white">{room.host.displayName}</strong></span>
                      <span className="text-slate-500 ml-1.5">{room.flag} {room.language}</span>
                    </div>
                  </div>
                </div>

                {/* Bottom Join CTA */}
                <div className="mt-4 pt-2 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-[11px] text-purple-300">
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{isSpeakingNow ? 'Voice active now' : 'Open mic'}</span>
                  </div>
                  <button className="px-3 py-1.5 rounded-xl bg-purple-600/90 group-hover:bg-purple-600 text-white font-semibold text-xs shadow-md transition-colors flex items-center gap-1">
                    <Radio className="w-3.5 h-3.5" />
                    <span>Join</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Suggested International Friends */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-cyan-400" />
            <h2 className="text-base font-bold text-white font-display">Vibe Pals to Meet</h2>
          </div>
          <button
            onClick={() => setCurrentTab('discover')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium"
          >
            Find more
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {activeUsers.map((user) => (
            <div
              key={user.id}
              className="bg-slate-900/60 border border-slate-800 hover:border-cyan-500/30 rounded-2xl p-4 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div
                    onClick={() => openUserProfile(user)}
                    className="flex items-center gap-2.5 cursor-pointer"
                  >
                    <div className="relative">
                      <img
                        src={user.avatar}
                        alt={user.displayName}
                        className="w-11 h-11 rounded-full object-cover border border-purple-500/30 bg-slate-800"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-900" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white hover:text-purple-300 transition-colors">
                        {user.displayName}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {user.flag} {user.country}
                      </p>
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-300 mt-2.5 line-clamp-2">
                  {user.bio}
                </p>

                {/* Languages unboxed */}
                <div className="mt-2.5 text-[10px] text-slate-400 flex items-center gap-1.5 flex-wrap">
                  <span className="text-purple-300 font-medium">{user.nativeLanguage}</span>
                  <span>·</span>
                  <span>Learning {user.learningLanguages[0]}</span>
                </div>
              </div>

              <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex items-center gap-2">
                <button
                  onClick={() => openChatWithUser(user)}
                  className="flex-1 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Message</span>
                </button>
                <button
                  onClick={() => openUserProfile(user)}
                  className="px-3 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 border border-purple-800/40 text-xs font-medium transition-colors"
                >
                  Profile
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
