import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Bell, ShieldCheck, Smartphone, Database, LogIn, Download } from 'lucide-react';

export const TopHeader: React.FC = () => {
  const {
    currentUser,
    isAuthenticated,
    setShowAuthModal,
    setShowAndroidGuide,
    setShowBackendStatusModal,
    setShowAdminDashboard,
    notifications,
    unreadNotificationCount,
    markAllNotificationsRead,
    isFirebaseMode,
    openUserProfile,
  } = useApp();

  const [showNotificationsDropdown, setShowNotificationsDropdown] = useState(false);

  return (
    <header className="sticky top-0 z-30 w-full bg-[#070b14]/90 backdrop-blur-xl border-b border-purple-900/20 px-4 py-2.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-500 to-cyan-400 p-[1.5px] shadow-lg shadow-purple-900/30">
              <div className="w-full h-full bg-[#070b14] rounded-[10px] flex items-center justify-center">
                <span className="text-sm font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-300">VT</span>
              </div>
            </div>
            <div>
              <span className="text-base font-black tracking-tight text-white font-display block leading-none">
                VIBE<span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">TALK</span>
              </span>
              <span className="text-[10px] text-purple-300/70 font-medium tracking-wider uppercase">Connect · Talk</span>
            </div>
          </div>
        </div>

        {/* Zone 2: System utilities & Status */}
        <div className="flex items-center gap-1.5 text-xs">
          {/* Direct ZIP download button */}
          <a
            href="/vibe-talk-project.zip"
            download="vibe-talk-project.zip"
            className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-800/50 text-cyan-300 transition-colors text-xs font-medium"
            title="Download Complete Project ZIP (1.05 MB)"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Project ZIP</span>
          </a>

          {/* Android Export Guide button - accessible on mobile & desktop */}
          <button
            onClick={() => setShowAndroidGuide(true)}
            className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-300 transition-colors text-xs"
            title="Export for Android & Play Store"
          >
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline font-medium">Android APK</span>
          </button>

          {/* Admin Dashboard button */}
          {currentUser.role === 'admin' && (
            <button
              onClick={() => setShowAdminDashboard(true)}
              className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-purple-950/40 hover:bg-purple-900/60 border border-purple-800/40 text-purple-300 transition-colors text-xs"
              title="Admin & Safety Dashboard"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-purple-300" />
              <span className="inline font-medium">Admin Portal</span>
            </button>
          )}
        </div>

        {/* Zone 3: Notification bell, User avatar & Persistent ANAS Label */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* Notifications dropdown trigger */}
          <div className="relative">
            <button
              onClick={() => setShowNotificationsDropdown((prev) => !prev)}
              className="relative p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800/80 transition-colors min-h-[38px] min-w-[38px] flex items-center justify-center"
              aria-label="View notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-[10px] font-bold text-white flex items-center justify-center animate-pulse">
                  {unreadNotificationCount}
                </span>
              )}
            </button>

            {/* Notifications Popover */}
            {showNotificationsDropdown && (
              <div className="absolute right-0 mt-2 w-80 max-h-96 overflow-y-auto bg-slate-900/95 backdrop-blur-2xl border border-purple-900/40 rounded-2xl shadow-2xl p-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs">
                  <span className="font-semibold text-white">Notifications</span>
                  {unreadNotificationCount > 0 && (
                    <button
                      onClick={markAllNotificationsRead}
                      className="text-purple-400 hover:text-purple-300 font-medium"
                    >
                      Mark all read
                    </button>
                  )}
                </div>
                <div className="space-y-2">
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-4">No notifications yet</p>
                  ) : (
                    notifications.map((notif) => (
                      <div
                        key={notif.id}
                        className={`p-2.5 rounded-xl border text-xs transition-colors ${
                          notif.isRead
                            ? 'bg-slate-950/40 border-slate-800/50 text-slate-400'
                            : 'bg-purple-950/30 border-purple-800/40 text-slate-200'
                        }`}
                      >
                        <p className="font-semibold text-slate-200">{notif.title}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5">{notif.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User profile avatar or Login button */}
          {isAuthenticated ? (
            <button
              onClick={() => openUserProfile(currentUser)}
              className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-800/60 transition-colors"
              title="View my profile"
            >
              <div className="relative">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.displayName}
                  className="w-8 h-8 rounded-full border border-purple-500/40 object-cover bg-slate-800"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#070b14]" />
              </div>
              <span className="text-xs font-semibold text-slate-200 hidden lg:inline max-w-[100px] truncate">
                {currentUser.displayName}
              </span>
            </button>
          ) : (
            <button
              onClick={() => setShowAuthModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-xs shadow-md shadow-purple-900/30 transition-all"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}

          {/* Persistent ANAS Header Brand Element */}
          <div className="flex items-center pl-1 sm:pl-2 shrink-0 border-l border-purple-900/40">
            <div className="px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-gradient-to-r from-purple-950/70 via-indigo-950/60 to-slate-900/80 border border-purple-500/30 shadow-sm shadow-purple-950/30 backdrop-blur-md flex items-center gap-1.5 select-none transition-all hover:border-purple-400/50">
              <span className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-400 to-cyan-400 shadow-[0_0_6px_rgba(168,85,247,0.7)]" />
              <span className="font-display font-extrabold text-[11px] sm:text-xs tracking-wider uppercase text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-indigo-200 to-cyan-300">
                ANAS
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
