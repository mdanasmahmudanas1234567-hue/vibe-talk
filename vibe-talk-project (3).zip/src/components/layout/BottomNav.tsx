import React from 'react';
import { useApp } from '../../context/AppContext';
import { Home, Compass, Radio, MessageSquare, User as UserIcon } from 'lucide-react';

interface NavItem {
  id: 'home' | 'discover' | 'rooms' | 'messages' | 'profile';
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  highlight?: boolean;
  badge?: number;
}

export const BottomNav: React.FC = () => {
  const { currentTab, setCurrentTab, conversations, activeRoom } = useApp();

  const totalUnreadMessages = conversations.reduce((acc, c) => acc + c.unreadCount, 0);

  const navItems: NavItem[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'discover', label: 'Discover', icon: Compass },
    { id: 'rooms', label: 'Voice Rooms', icon: Radio, highlight: true },
    { id: 'messages', label: 'Messages', icon: MessageSquare, badge: totalUnreadMessages },
    { id: 'profile', label: 'Profile', icon: UserIcon },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070b14]/95 backdrop-blur-2xl border-t border-purple-950/60 pb-[env(safe-area-inset-bottom,8px)] transition-all">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          if (item.highlight) {
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className="relative -top-3 flex flex-col items-center justify-center min-h-[48px] min-w-[48px] focus:outline-none group"
                aria-label={item.label}
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 ${
                    isActive || activeRoom
                      ? 'bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 text-white shadow-purple-900/50 ring-2 ring-purple-400/30'
                      : 'bg-slate-800 text-slate-300 border border-purple-900/40 hover:bg-slate-700'
                  }`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <span
                  className={`text-[10px] font-semibold mt-1 tracking-tight transition-colors ${
                    isActive ? 'text-purple-400' : 'text-slate-400'
                  }`}
                >
                  {item.label}
                </span>
                {activeRoom && (
                  <span className="absolute top-1 right-2 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#070b14] animate-pulse" />
                )}
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className="relative flex flex-col items-center justify-center min-h-[44px] min-w-[44px] py-1.5 focus:outline-none transition-colors group"
              aria-label={item.label}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform active:scale-90 ${
                    isActive ? 'text-purple-400 stroke-[2.2]' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                {item.badge && item.badge > 0 ? (
                  <span className="absolute -top-1.5 -right-2 min-w-[16px] h-4 px-1 rounded-full bg-pink-500 text-[10px] font-bold text-white flex items-center justify-center shadow-sm">
                    {item.badge}
                  </span>
                ) : null}
              </div>
              <span
                className={`text-[10px] font-medium tracking-tight mt-1 transition-colors ${
                  isActive ? 'text-purple-300 font-semibold' : 'text-slate-400'
                }`}
              >
                {item.label}
              </span>
              {isActive && (
                <span className="w-1 h-1 rounded-full bg-purple-400 mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
