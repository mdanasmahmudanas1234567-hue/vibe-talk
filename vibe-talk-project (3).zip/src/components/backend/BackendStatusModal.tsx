import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Database, Radio, Mic, MicOff, X, CheckCircle2, AlertCircle, Info, ExternalLink } from 'lucide-react';
import { getServiceStatus } from '../../services/firebase';
import { audioEngine } from '../../services/audioEngine';

export const BackendStatusModal: React.FC = () => {
  const { showBackendStatusModal, setShowBackendStatusModal, isRealMicActive } = useApp();
  const [testMicActive, setTestMicActive] = useState(false);
  const [testVolume, setTestVolume] = useState(0);

  if (!showBackendStatusModal) return null;

  const status = getServiceStatus();

  const handleTestMicToggle = async () => {
    if (testMicActive) {
      audioEngine.stopMicrophone();
      setTestMicActive(false);
      setTestVolume(0);
    } else {
      const ok = await audioEngine.startMicrophone((vol) => {
        setTestVolume(vol);
      });
      setTestMicActive(ok);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-900 border border-purple-900/50 rounded-3xl p-6 shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-950/80 border border-purple-800 text-purple-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-display">
                Backend & Voice Engine Diagnostics
              </h2>
              <p className="text-xs text-slate-400">Service configurations and connection health</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (testMicActive) audioEngine.stopMicrophone();
              setShowBackendStatusModal(false);
            }}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Diagnostic Cards */}
        <div className="flex-1 overflow-y-auto space-y-3.5 py-4 pr-1 text-xs">
          {/* Firebase Diagnostic */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-purple-400" />
                <span>Firebase Authentication & Cloud Firestore</span>
              </span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 ${
                  status.firebaseConnected
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}
              >
                {status.firebaseConnected ? <CheckCircle2 className="w-3 h-3" /> : <Info className="w-3 h-3" />}
                <span>{status.firebaseConnected ? 'Connected (Live)' : 'Local Demo Mode'}</span>
              </span>
            </div>
            <p className="text-slate-300 leading-relaxed">
              {status.firebaseConnected
                ? 'Firebase SDK is initialized with production credentials. User profiles and auth state are synchronized to Google Cloud Firestore.'
                : 'Operating in Local Storage Demo Mode with persistent guest profiles, mock users, simulated messaging, and active rooms. Add VITE_FIREBASE_API_KEY and VITE_FIREBASE_PROJECT_ID to connect your live Firebase project.'}
            </p>
          </div>

          {/* LiveKit Voice Stage Diagnostic */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-white flex items-center gap-2">
                <Radio className="w-4 h-4 text-cyan-400" />
                <span>Real-Time Voice Engine (WebRTC / LiveKit)</span>
              </span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 ${
                  status.livekitConnected
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                }`}
              >
                <CheckCircle2 className="w-3 h-3" />
                <span>{status.livekitConnected ? 'LiveKit Cloud' : 'Browser Web Audio Mesh'}</span>
              </span>
            </div>
            <p className="text-slate-300 leading-relaxed">
              Real microphone audio input is captured via HTML5 Web Audio API & AnalyserNode. Avatar rings pulse in real time with speaking frequency. To connect a remote LiveKit server, set <code className="text-purple-300 font-mono">VITE_LIVEKIT_URL</code> in environment variables.
            </p>
          </div>

          {/* Interactive Microphone Test */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-white flex items-center gap-2">
                <Mic className="w-4 h-4 text-emerald-400" />
                <span>Microphone Audio Input Test</span>
              </span>
              <button
                onClick={handleTestMicToggle}
                className={`px-3 py-1 rounded-xl font-semibold text-xs transition-colors flex items-center gap-1.5 ${
                  testMicActive
                    ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                }`}
              >
                {testMicActive ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                <span>{testMicActive ? 'Stop Mic' : 'Test Mic'}</span>
              </button>
            </div>

            <p className="text-slate-300 mb-3">
              Tap "Test Mic" and grant browser microphone permission to see live voice frequency levels:
            </p>

            {/* Volume indicator bar */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 flex items-center gap-3">
              <div className="flex-1 bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 transition-all duration-75"
                  style={{ width: `${testVolume}%` }}
                />
              </div>
              <span className="font-mono text-slate-300 w-10 text-right">{testVolume}%</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex justify-end shrink-0">
          <button
            onClick={() => {
              if (testMicActive) audioEngine.stopMicrophone();
              setShowBackendStatusModal(false);
            }}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs"
          >
            Close Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
};
