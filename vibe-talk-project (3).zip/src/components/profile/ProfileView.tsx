import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Edit3,
  Users,
  Shield,
  Volume2,
  Trash2,
  LogOut,
  Smartphone,
  Database,
  Check,
  X,
  Plus,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { audioEngine } from '../../services/audioEngine';

export const ProfileView: React.FC = () => {
  const {
    currentUser,
    updateCurrentUserProfile,
    friends,
    removeFriend,
    friendRequests,
    acceptFriendRequest,
    declineFriendRequest,
    blockedUserIds,
    unblockUser,
    users,
    deleteAccount,
    logout,
    setShowAdminDashboard,
    setShowAndroidGuide,
    setShowBackendStatusModal,
  } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState(currentUser.displayName);
  const [bio, setBio] = useState(currentUser.bio);
  const [country, setCountry] = useState(currentUser.country);
  const [nativeLanguage, setNativeLanguage] = useState(currentUser.nativeLanguage);
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'friends' | 'requests' | 'privacy'>('profile');
  const [isPlayingVoiceBio, setIsPlayingVoiceBio] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateCurrentUserProfile({
      displayName,
      bio,
      country,
      nativeLanguage,
    });
    setIsEditing(false);
    audioEngine.playSoundEffect('ding');
  };

  const playVoiceBio = () => {
    setIsPlayingVoiceBio(true);
    audioEngine.playChime(440, 0.4, 'triangle');
    setTimeout(() => {
      audioEngine.playChime(660, 0.4, 'sine');
    }, 400);
    setTimeout(() => {
      audioEngine.playChime(880, 0.5, 'sine');
      setIsPlayingVoiceBio(false);
    }, 800);
  };

  const blockedUsers = users.filter((u) => blockedUserIds.includes(u.id));

  return (
    <div className="space-y-5 pb-24 pt-2">
      {/* Profile Card Header */}
      <div className="relative overflow-hidden bg-slate-900/80 border border-purple-900/40 rounded-3xl p-5 shadow-xl">
        <div className="absolute top-0 right-0 w-48 h-48 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <img
                src={currentUser.avatar}
                alt={currentUser.displayName}
                className="w-16 h-16 rounded-full object-cover border-2 border-purple-500/60 shadow-lg bg-slate-800"
              />
              <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#070b14]" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-white font-display">
                  {currentUser.displayName}
                </h1>
                <span className="text-xs">{currentUser.flag}</span>
              </div>
              <p className="text-xs text-purple-300/80">@{currentUser.username}</p>
              <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                <span>{currentUser.country}</span>
                <span>·</span>
                <span className="text-emerald-400 font-medium">Reputation {currentUser.reputationScore}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsEditing(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900/80 border border-purple-800/50 text-purple-200 text-xs font-semibold transition-colors shrink-0"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit Profile</span>
          </button>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-800/80 text-center">
          <div>
            <span className="block text-sm font-bold text-white">{friends.length}</span>
            <span className="text-[10px] text-slate-400">Friends</span>
          </div>
          <div>
            <span className="block text-sm font-bold text-white">{currentUser.followersCount}</span>
            <span className="text-[10px] text-slate-400">Followers</span>
          </div>
          <div>
            <span className="block text-sm font-bold text-white">{currentUser.followingCount}</span>
            <span className="text-[10px] text-slate-400">Following</span>
          </div>
        </div>

        {/* Voice Bio preview button */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
          <button
            onClick={playVoiceBio}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-purple-300 text-xs font-medium transition-colors"
          >
            <Volume2 className={`w-3.5 h-3.5 ${isPlayingVoiceBio ? 'text-emerald-400 animate-pulse' : ''}`} />
            <span>{isPlayingVoiceBio ? 'Playing audio snippet...' : 'Listen to Voice Bio (3s)'}</span>
          </button>
          <span className="text-[10px] text-slate-500">{currentUser.joinedDate}</span>
        </div>
      </div>

      {/* Profile Section Tabs */}
      <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'profile', label: 'About & Languages' },
          { id: 'friends', label: `Friends (${friends.length})` },
          { id: 'requests', label: `Requests (${friendRequests.length})` },
          { id: 'privacy', label: 'Safety & Settings' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeSubTab === tab.id
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Sub Tab: Profile Bio & Languages */}
      {activeSubTab === 'profile' && (
        <div className="space-y-4">
          {/* Bio */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">About Me</h3>
            <p className="text-xs text-slate-200 leading-relaxed">{currentUser.bio}</p>
          </div>

          {/* Languages */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Languages</h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Native:</span>
                <span className="font-semibold text-purple-300">{currentUser.nativeLanguage}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Learning:</span>
                <span className="font-semibold text-cyan-300">
                  {currentUser.learningLanguages.join(', ')}
                </span>
              </div>
            </div>
          </div>

          {/* Interests */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Interests</h3>
            <div className="flex flex-wrap gap-1.5">
              {currentUser.interests.map((interest) => (
                <span
                  key={interest}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700/60 text-slate-300 text-[11px]"
                >
                  {interest}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Sub Tab: Friends */}
      {activeSubTab === 'friends' && (
        <div className="space-y-2">
          {friends.length === 0 ? (
            <div className="text-center py-8 bg-slate-900/40 rounded-2xl border border-slate-800">
              <Users className="w-6 h-6 text-slate-600 mx-auto mb-2" />
              <p className="text-xs text-slate-400">You haven't added any friends yet</p>
            </div>
          ) : (
            friends.map((friend) => (
              <div
                key={friend.id}
                className="bg-slate-900/60 border border-slate-800 rounded-2xl p-3 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <img
                    src={friend.avatar}
                    alt={friend.displayName}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-white">{friend.displayName}</h4>
                    <p className="text-[10px] text-slate-400">{friend.flag} {friend.country}</p>
                  </div>
                </div>

                <button
                  onClick={() => removeFriend(friend.id)}
                  className="text-xs text-red-400 hover:text-red-300 px-2.5 py-1 rounded-lg bg-red-950/40 border border-red-900/40"
                >
                  Remove
                </button>
              </div>
            ))
          )}
        </div>
      )}

      {/* Sub Tab: Friend Requests */}
      {activeSubTab === 'requests' && (
        <div className="space-y-2">
          {friendRequests.length === 0 ? (
            <div className="text-center py-8 bg-slate-900/40 rounded-2xl border border-slate-800">
              <p className="text-xs text-slate-400">No pending friend requests</p>
            </div>
          ) : (
            friendRequests.map((req) => (
              <div
                key={req.id}
                className="bg-slate-900/60 border border-slate-800 rounded-2xl p-3 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <img
                    src={req.fromUser.avatar}
                    alt={req.fromUser.displayName}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-white">{req.fromUser.displayName}</h4>
                    <p className="text-[10px] text-slate-400">@{req.fromUser.username} · {req.fromUser.country}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => acceptFriendRequest(req.id)}
                    className="p-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white"
                    title="Accept"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => declineFriendRequest(req.id)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                    title="Decline"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Sub Tab: Safety & Settings */}
      {activeSubTab === 'privacy' && (
        <div className="space-y-3">
          {/* Admin Dashboard launcher */}
          {currentUser.role === 'admin' && (
            <div className="bg-purple-950/40 border border-purple-800/40 rounded-2xl p-4 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-purple-400" />
                  <span>Admin Moderation Dashboard</span>
                </h4>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  Review reported users, audio violations, and room audit logs
                </p>
              </div>
              <button
                onClick={() => setShowAdminDashboard(true)}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"
              >
                Open
              </button>
            </div>
          )}

          {/* Android Guide */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <span>Export for Android & Play Store</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Build APK/AAB, configure microphone permissions, and submit
              </p>
            </div>
            <button
              onClick={() => setShowAndroidGuide(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold"
            >
              Guide
            </button>
          </div>

          {/* Backend Diagnostics */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Database className="w-4 h-4 text-purple-400" />
                <span>Firebase & WebRTC Status</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                LiveKit credentials, Cloud Firestore configuration
              </p>
            </div>
            <button
              onClick={() => setShowBackendStatusModal(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-300 text-xs font-semibold"
            >
              Config
            </button>
          </div>

          {/* Blocked Users */}
          {blockedUsers.length > 0 && (
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
              <h4 className="text-xs font-bold text-slate-300 mb-2">Blocked Users</h4>
              <div className="space-y-2">
                {blockedUsers.map((bUser) => (
                  <div key={bUser.id} className="flex items-center justify-between text-xs">
                    <span className="text-slate-300">{bUser.displayName}</span>
                    <button
                      onClick={() => unblockUser(bUser.id)}
                      className="text-cyan-400 hover:underline"
                    >
                      Unblock
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Account Actions */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-3">
            <button
              onClick={logout}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out</span>
            </button>

            <button
              onClick={deleteAccount}
              className="w-full py-2.5 rounded-xl bg-red-950/40 hover:bg-red-900/50 border border-red-900/40 text-red-400 text-xs font-semibold flex items-center justify-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete Account & Data</span>
            </button>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-purple-900/50 rounded-3xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-sm font-bold text-white">Edit Profile</h3>
              <button onClick={() => setIsEditing(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Display Name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Bio</label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Country</label>
                  <input
                    type="text"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Native Language</label>
                  <input
                    type="text"
                    value={nativeLanguage}
                    onChange={(e) => setNativeLanguage(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
