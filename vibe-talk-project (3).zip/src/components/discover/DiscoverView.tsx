import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Search, Radio, MessageCircle, UserPlus, Volume2, Check } from 'lucide-react';
import { VoiceRoom } from '../../types';

export const DiscoverView: React.FC = () => {
  const { rooms, users, joinRoom, openUserProfile, openChatWithUser, sendFriendRequest, friends } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<string>('All');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');
  const [requestedFriendIds, setRequestedFriendIds] = useState<string[]>([]);

  const topics = [
    'All',
    'Language Exchange',
    'Music & Chill',
    'Late Night Vibes',
    'Tech & Startups',
    'Deep Talks',
    'Gaming',
  ];

  const languages = ['All', 'Japanese', 'Spanish', 'English', 'Korean', 'French', 'German', 'Arabic'];

  // Filtered rooms
  const filteredRooms = useMemo(() => {
    return rooms.filter((room) => {
      const matchesTopic = selectedTopic === 'All' || room.topic === selectedTopic;
      const matchesLanguage =
        selectedLanguage === 'All' || room.language.toLowerCase().includes(selectedLanguage.toLowerCase());
      const matchesSearch =
        searchQuery === '' ||
        room.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        room.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        room.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchesTopic && matchesLanguage && matchesSearch;
    });
  }, [rooms, selectedTopic, selectedLanguage, searchQuery]);

  // Filtered users
  const filteredUsers = useMemo(() => {
    if (!searchQuery && selectedLanguage === 'All') return users;

    return users.filter((user) => {
      const matchesQuery =
        searchQuery === '' ||
        user.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.interests.some((i) => i.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesLang =
        selectedLanguage === 'All' ||
        user.nativeLanguage.toLowerCase().includes(selectedLanguage.toLowerCase()) ||
        user.learningLanguages.some((l) => l.toLowerCase().includes(selectedLanguage.toLowerCase()));

      return matchesQuery && matchesLang;
    });
  }, [users, searchQuery, selectedLanguage]);

  const handleFriendRequest = (userId: string, user: (typeof users)[0]) => {
    sendFriendRequest(user);
    setRequestedFriendIds((prev) => [...prev, userId]);
  };

  return (
    <div className="space-y-6 pb-24 pt-2">
      {/* Header & Search */}
      <div className="space-y-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-display">Discover Global Vibes</h1>
          <p className="text-xs text-slate-400">Explore live stages and meet people from 50+ countries</p>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search rooms, topics, Japanese, Spanish, tech..."
            className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl pl-10 pr-4 py-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors"
          />
        </div>
      </div>

      {/* Topic Filter Buttons (Segmented Controls) */}
      <div className="space-y-2">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Browse by Topic</span>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {topics.map((topic) => (
            <button
              key={topic}
              onClick={() => setSelectedTopic(topic)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 transition-colors min-h-[36px] ${
                selectedTopic === topic
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-900/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {topic}
            </button>
          ))}
        </div>
      </div>

      {/* Language Filter */}
      <div className="space-y-2">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Language Filter</span>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {languages.map((lang) => (
            <button
              key={lang}
              onClick={() => setSelectedLanguage(lang)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 transition-colors min-h-[36px] ${
                selectedLanguage === lang
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-900/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {lang}
            </button>
          ))}
        </div>
      </div>

      {/* Live Voice Rooms Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white font-display uppercase tracking-wider">
            Live Voice Stages ({filteredRooms.length})
          </h2>
        </div>

        {filteredRooms.length === 0 ? (
          <div className="text-center py-10 bg-slate-900/40 rounded-2xl border border-slate-800">
            <Radio className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-xs text-slate-400 font-medium">No voice rooms match your current filters</p>
            <button
              onClick={() => {
                setSelectedTopic('All');
                setSelectedLanguage('All');
                setSearchQuery('');
              }}
              className="mt-2 text-xs text-purple-400 hover:underline"
            >
              Clear all filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredRooms.map((room) => (
              <div
                key={room.id}
                onClick={() => joinRoom(room)}
                className="bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-purple-500/40 rounded-2xl p-4 transition-all cursor-pointer shadow-lg flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-[11px] font-semibold text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded-md border border-purple-800/40">
                      {room.topic}
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      {room.flag} {room.language}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white line-clamp-1">{room.title}</h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{room.description}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <img
                      src={room.host.avatar}
                      alt={room.host.displayName}
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="truncate max-w-[120px]">{room.host.displayName}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-emerald-400 font-medium">
                      {room.totalParticipantsCount} listening
                    </span>
                    <button className="px-3 py-1 rounded-xl bg-purple-600 text-white text-xs font-semibold">
                      Join
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Community Members Section */}
      <div className="space-y-3 pt-2">
        <h2 className="text-sm font-bold text-white font-display uppercase tracking-wider">
          Community Members ({filteredUsers.length})
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filteredUsers.map((user) => {
            const isAlreadyFriend = friends.some((f) => f.id === user.id);
            const isRequested = requestedFriendIds.includes(user.id);

            return (
              <div
                key={user.id}
                className="bg-slate-900/60 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between gap-3"
              >
                <div
                  onClick={() => openUserProfile(user)}
                  className="flex items-center gap-3 cursor-pointer min-w-0"
                >
                  <img
                    src={user.avatar}
                    alt={user.displayName}
                    className="w-12 h-12 rounded-full object-cover border border-purple-500/30 bg-slate-800 shrink-0"
                  />
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-white truncate hover:text-purple-300">
                      {user.displayName}
                    </h4>
                    <p className="text-[11px] text-slate-400 truncate">
                      {user.flag} {user.country} · Native {user.nativeLanguage}
                    </p>
                    <div className="flex items-center gap-1 mt-1 text-[10px] text-purple-300/80">
                      <span>Score {user.reputationScore}</span>
                      <span>·</span>
                      <span>{user.learningLanguages[0]}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => openChatWithUser(user)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 transition-colors"
                    title="Send message"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>

                  {!isAlreadyFriend ? (
                    <button
                      disabled={isRequested}
                      onClick={() => handleFriendRequest(user.id, user)}
                      className={`p-2 rounded-xl text-xs font-medium transition-colors ${
                        isRequested
                          ? 'bg-purple-950 text-purple-300'
                          : 'bg-purple-600 hover:bg-purple-500 text-white'
                      }`}
                      title={isRequested ? 'Request sent' : 'Add friend'}
                    >
                      {isRequested ? <Check className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                    </button>
                  ) : (
                    <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-1 rounded-lg">
                      Friend
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
