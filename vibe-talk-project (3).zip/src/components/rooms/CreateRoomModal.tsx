import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Radio, Lock, Globe, Sparkles } from 'lucide-react';
import { VoiceRoom } from '../../types';

export const CreateRoomModal: React.FC = () => {
  const { showCreateRoomModal, setShowCreateRoomModal, createRoom } = useApp();

  const [title, setTitle] = useState('');
  const [topic, setTopic] = useState<VoiceRoom['topic']>('Language Exchange');
  const [language, setLanguage] = useState('English');
  const [description, setDescription] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [pinCode, setPinCode] = useState('');

  if (!showCreateRoomModal) return null;

  const topics: VoiceRoom['topic'][] = [
    'Language Exchange',
    'Music & Chill',
    'Late Night Vibes',
    'Deep Talks',
    'Gaming',
    'Tech & Startups',
    'Culture & Travel',
  ];

  const languages = [
    'English',
    'Japanese / English',
    'Spanish / English',
    'Korean / English',
    'French',
    'German',
    'Mandarin Chinese',
    'Arabic',
    'Portuguese',
    'Italian',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    createRoom({
      title: title.trim(),
      topic,
      language,
      description: description.trim() || 'Casual open conversation. Be kind and respectful!',
      isPrivate,
      pinCode: isPrivate ? pinCode : undefined,
    });

    setShowCreateRoomModal(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-slate-900 border border-purple-900/50 rounded-3xl p-6 shadow-2xl relative">
        <button
          onClick={() => setShowCreateRoomModal(false)}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-xl bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-500 p-0.5">
            <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center">
              <Radio className="w-4 h-4 text-purple-400" />
            </div>
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Create Voice Room</h3>
            <p className="text-xs text-slate-400">Host your own audio community</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Room Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. ☕ Midnight Lo-Fi & Coffee Talks"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Topic
              </label>
              <select
                value={topic}
                onChange={(e) => setTopic(e.target.value as VoiceRoom['topic'])}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500"
              >
                {topics.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Primary Language
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500"
              >
                {languages.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Description / Guidelines
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What are we talking about? (e.g. Practicing beginner phrases, sharing stories)"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Privacy Switch */}
          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isPrivate ? (
                <Lock className="w-4 h-4 text-purple-400" />
              ) : (
                <Globe className="w-4 h-4 text-cyan-400" />
              )}
              <div>
                <p className="text-xs font-semibold text-white">
                  {isPrivate ? 'Private Room (PIN required)' : 'Public Room (Everyone can join)'}
                </p>
                <p className="text-[11px] text-slate-400">
                  {isPrivate ? 'Only people with the PIN can enter' : 'Visible on Discover & Home feed'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsPrivate(!isPrivate)}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                isPrivate ? 'bg-purple-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                  isPrivate ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {isPrivate && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                4-Digit PIN Code
              </label>
              <input
                type="text"
                maxLength={4}
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value)}
                placeholder="e.g. 1234"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500 font-mono"
              />
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs shadow-lg shadow-purple-900/40 flex items-center justify-center gap-2 transition-all active:scale-98"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch Voice Room</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
