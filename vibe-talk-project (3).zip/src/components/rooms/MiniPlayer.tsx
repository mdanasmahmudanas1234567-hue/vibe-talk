import React from 'react';
import { useApp } from '../../context/AppContext';
import { Mic, MicOff, PhoneOff, Maximize2 } from 'lucide-react';

export const MiniPlayer: React.FC = () => {
  const { activeRoom, isRoomMinimized, toggleRoomMinimize, leaveRoom, isMuted, toggleMic } = useApp();

  if (!activeRoom || !isRoomMinimized) return null;

  const speakers = activeRoom.participants.filter((p) => p.role === 'host' || p.role === 'speaker');

  return (
    <div className="fixed bottom-16 left-0 right-0 z-30 px-3 pb-2 transition-all">
      <div className="max-w-md mx-auto bg-slate-900/95 backdrop-blur-2xl border border-purple-500/30 rounded-2xl shadow-2xl p-2.5 flex items-center justify-between gap-3">
        {/* Left: Room Info & Active Speakers */}
        <div
          onClick={toggleRoomMinimize}
          className="flex items-center gap-2.5 flex-1 min-w-0 cursor-pointer"
        >
          <div className="relative shrink-0">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 to-cyan-500 p-0.5">
              <img
                src={activeRoom.host.avatar}
                alt={activeRoom.host.displayName}
                className="w-full h-full rounded-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {speakers.some((s) => s.isSpeaking) && (
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-400 ring-2 ring-slate-900 animate-ping" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs">{activeRoom.flag}</span>
              <p className="text-xs font-bold text-white truncate">{activeRoom.title}</p>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-purple-300/80">
              <span>{activeRoom.participants.length} online</span>
              <span>·</span>
              <div className="flex items-center gap-0.5">
                <span className="w-1 h-2 bg-purple-400 rounded-full animate-pulse" />
                <span className="w-1 h-3 bg-purple-400 rounded-full animate-pulse delay-75" />
                <span className="w-1 h-1.5 bg-purple-400 rounded-full animate-pulse delay-150" />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Quick Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={toggleMic}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors min-h-[36px] min-w-[36px] ${
              isMuted
                ? 'bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30'
            }`}
            title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <button
            onClick={toggleRoomMinimize}
            className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
            title="Expand room stage"
          >
            <Maximize2 className="w-4 h-4" />
          </button>

          <button
            onClick={leaveRoom}
            className="w-9 h-9 rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-900/30 flex items-center justify-center transition-colors"
            title="Leave voice room"
          >
            <PhoneOff className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
