import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ChevronDown,
  PhoneOff,
  Mic,
  MicOff,
  Hand,
  MessageSquare,
  Sparkles,
  Share2,
  Crown,
  Volume2,
  MoreVertical,
  X,
  Send,
  Flag,
  UserPlus,
  Shield,
  VolumeX,
} from 'lucide-react';
import { audioEngine } from '../../services/audioEngine';
import confetti from 'canvas-confetti';

export const ActiveRoomStage: React.FC = () => {
  const {
    activeRoom,
    isRoomMinimized,
    toggleRoomMinimize,
    leaveRoom,
    currentUser,
    isMuted,
    isRealMicActive,
    myMicVolume,
    toggleMic,
    raisedHand,
    toggleHandRaise,
    roomChatMessages,
    sendRoomChatMessage,
    floatingReactions,
    sendReaction,
    promoteToSpeaker,
    demoteToListener,
    muteParticipant,
    kickParticipant,
    openUserProfile,
    closeRoom,
    setShowBackendStatusModal,
  } = useApp();

  const [showChat, setShowChat] = useState<boolean>(true);
  const [chatInput, setChatInput] = useState<string>('');
  const [selectedParticipantId, setSelectedParticipantId] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [roomChatMessages, showChat]);

  if (!activeRoom || isRoomMinimized) return null;

  const isHost = activeRoom.hostId === currentUser.id;
  const myParticipant = activeRoom.participants.find((p) => p.user.id === currentUser.id);
  const isSpeakerOrHost = myParticipant?.role === 'host' || myParticipant?.role === 'speaker';

  const speakers = activeRoom.participants.filter(
    (p) => p.role === 'host' || p.role === 'speaker' || p.role === 'moderator'
  );
  const listeners = activeRoom.participants.filter((p) => p.role === 'listener');
  const handRaisers = activeRoom.participants.filter((p) => p.raisedHand);

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    sendRoomChatMessage(chatInput);
    setChatInput('');
  };

  const triggerConfettiParty = () => {
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 },
      colors: ['#a855f7', '#3b82f6', '#06b6d4', '#ec4899'],
    });
    audioEngine.playSoundEffect('cheer');
    sendReaction('🎉');
  };

  const selectedParticipant = activeRoom.participants.find(
    (p) => p.user.id === selectedParticipantId
  );

  return (
    <div className="fixed inset-0 z-50 bg-[#070b14] flex flex-col overflow-hidden animate-in fade-in duration-200">
      {/* Floating Reactions Overlay */}
      <div className="pointer-events-none absolute inset-0 z-40 overflow-hidden">
        {floatingReactions.map((r) => (
          <div
            key={r.id}
            style={{ left: `${r.x}%`, bottom: '110px' }}
            className="absolute flex flex-col items-center animate-float-reaction"
          >
            <span className="text-3xl drop-shadow-lg">{r.emoji}</span>
            <span className="text-[10px] text-white/80 bg-black/50 px-1.5 py-0.5 rounded-full mt-0.5 backdrop-blur-sm">
              {r.senderName.split(' ')[0]}
            </span>
          </div>
        ))}
      </div>

      {/* Top Bar Header */}
      <div className="px-4 py-3 bg-slate-950/80 backdrop-blur-xl border-b border-purple-900/30 flex items-center justify-between gap-3 shrink-0">
        <button
          onClick={toggleRoomMinimize}
          className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 transition-colors"
          title="Minimize room"
          aria-label="Minimize room"
        >
          <ChevronDown className="w-5 h-5" />
        </button>

        <div className="flex-1 min-w-0 text-center">
          <div className="flex items-center justify-center gap-1.5">
            <span className="text-sm">{activeRoom.flag}</span>
            <h2 className="text-sm font-bold text-white truncate max-w-[220px]">
              {activeRoom.title}
            </h2>
          </div>
          <div className="flex items-center justify-center gap-2 text-[11px] text-purple-300/80 mt-0.5">
            <span>{activeRoom.topic}</span>
            <span>·</span>
            <span>{activeRoom.language}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleShare}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 transition-colors relative"
            title="Share room"
          >
            <Share2 className="w-4 h-4" />
            {copiedLink && (
              <span className="absolute -bottom-7 right-0 text-[10px] bg-purple-600 text-white px-2 py-0.5 rounded whitespace-nowrap shadow-lg">
                Link copied!
              </span>
            )}
          </button>

          <button
            onClick={leaveRoom}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800/40 text-xs font-semibold transition-colors"
            title="Leave voice stage"
          >
            <PhoneOff className="w-3.5 h-3.5" />
            <span>Leave</span>
          </button>

          {/* Persistent ANAS Header Brand Element in Live Stage */}
          <div className="flex items-center pl-1 sm:pl-1.5 border-l border-purple-900/40 shrink-0">
            <div className="px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-gradient-to-r from-purple-950/70 via-indigo-950/60 to-slate-900/80 border border-purple-500/30 shadow-sm backdrop-blur-md flex items-center gap-1.5 select-none">
              <span className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-400 to-cyan-400 shadow-[0_0_6px_rgba(168,85,247,0.7)]" />
              <span className="font-display font-extrabold text-[11px] sm:text-xs tracking-wider uppercase text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-indigo-200 to-cyan-300">
                ANAS
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Diagnostics / Service Banner */}
      <div className="px-4 py-1.5 bg-gradient-to-r from-purple-950/40 via-indigo-950/40 to-slate-950/40 border-b border-purple-900/20 flex items-center justify-between text-[11px] text-purple-300/80 shrink-0">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>
            {isRealMicActive
              ? 'Real Microphone Connected'
              : 'WebRTC / Web Audio Voice Mesh (Active)'}
          </span>
        </div>
        <button
          onClick={() => setShowBackendStatusModal(true)}
          className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px]"
        >
          <span>LiveKit / Backend Info</span>
        </button>
      </div>

      {/* Main Stage Content: Speakers & Listeners */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
        {/* Host Requests Banner (if any hand raises) */}
        {isHost && handRaisers.length > 0 && (
          <div className="bg-purple-950/60 border border-purple-600/40 rounded-2xl p-3 shadow-lg animate-in slide-in-from-top-2">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-purple-200 flex items-center gap-1.5">
                <Hand className="w-4 h-4 text-purple-400" /> Speaking Requests ({handRaisers.length})
              </span>
            </div>
            <div className="space-y-2">
              {handRaisers.map((participant) => (
                <div
                  key={participant.user.id}
                  className="flex items-center justify-between bg-slate-900/80 rounded-xl p-2"
                >
                  <div className="flex items-center gap-2">
                    <img
                      src={participant.user.avatar}
                      alt={participant.user.displayName}
                      className="w-7 h-7 rounded-full object-cover"
                    />
                    <div>
                      <p className="text-xs font-semibold text-white">{participant.user.displayName}</p>
                      <p className="text-[10px] text-slate-400">{participant.user.flag} {participant.user.country}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => promoteToSpeaker(participant.user.id)}
                      className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-medium"
                    >
                      Accept
                    </button>
                    <button
                      onClick={() => demoteToListener(participant.user.id)}
                      className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Stage Speakers Section */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <span>Speakers</span>
              <span className="text-purple-400 font-semibold">({speakers.length}/{activeRoom.maxSpeakers})</span>
            </h3>
            {isHost && (
              <button
                onClick={() => {
                  if (confirm('Are you sure you want to close this voice room for everyone?')) {
                    closeRoom(activeRoom.id);
                  }
                }}
                className="text-[11px] text-red-400 hover:text-red-300"
              >
                Close Room
              </button>
            )}
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
            {speakers.map((participant) => {
              const isCurrentUser = participant.user.id === currentUser.id;
              const isSpeakingNow = isCurrentUser ? !isMuted && myMicVolume > 15 : participant.isSpeaking;

              return (
                <div
                  key={participant.user.id}
                  onClick={() => {
                    if (isHost && !isCurrentUser) {
                      setSelectedParticipantId(participant.user.id);
                    } else {
                      openUserProfile(participant.user);
                    }
                  }}
                  className="flex flex-col items-center group cursor-pointer"
                >
                  <div className="relative">
                    {/* Glowing audio wave ring when speaking */}
                    <div
                      className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center p-1 transition-all ${
                        isSpeakingNow
                          ? 'ring-4 ring-purple-500 shadow-lg shadow-purple-600/50 scale-105'
                          : 'ring-2 ring-slate-800'
                      }`}
                    >
                      <img
                        src={participant.user.avatar}
                        alt={participant.user.displayName}
                        className="w-full h-full rounded-full object-cover bg-slate-800"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Host Crown */}
                    {participant.role === 'host' && (
                      <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-amber-500 text-slate-950 p-1 rounded-full shadow-md">
                        <Crown className="w-3 h-3 fill-current" />
                      </span>
                    )}

                    {/* Mute / Speaking Badge */}
                    <span
                      className={`absolute bottom-0 right-0 p-1 rounded-full text-white shadow-md ${
                        participant.isMuted || (isCurrentUser && isMuted)
                          ? 'bg-red-500/90'
                          : 'bg-emerald-500'
                      }`}
                    >
                      {participant.isMuted || (isCurrentUser && isMuted) ? (
                        <MicOff className="w-3 h-3" />
                      ) : (
                        <Mic className="w-3 h-3" />
                      )}
                    </span>
                  </div>

                  <div className="text-center mt-2 w-full">
                    <p className="text-xs font-semibold text-white truncate max-w-[90px] mx-auto">
                      {participant.user.displayName}
                    </p>
                    <span className="text-[10px] text-slate-400 block truncate">
                      {participant.role === 'host' ? 'Host' : 'Speaker'} · {participant.user.flag}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Listeners Section */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <span>Listeners</span>
              <span className="text-slate-500 font-semibold">({listeners.length})</span>
            </h3>
          </div>

          {listeners.length === 0 ? (
            <div className="text-center py-6 border border-dashed border-slate-800/80 rounded-2xl bg-slate-950/30">
              <p className="text-xs text-slate-500">No other listeners currently in room</p>
            </div>
          ) : (
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
              {listeners.map((participant) => (
                <div
                  key={participant.user.id}
                  onClick={() => {
                    if (isHost && participant.user.id !== currentUser.id) {
                      setSelectedParticipantId(participant.user.id);
                    } else {
                      openUserProfile(participant.user);
                    }
                  }}
                  className="flex flex-col items-center group cursor-pointer"
                >
                  <div className="relative">
                    <img
                      src={participant.user.avatar}
                      alt={participant.user.displayName}
                      className="w-12 h-12 rounded-full object-cover border border-slate-800 hover:border-purple-500 transition-colors"
                      referrerPolicy="no-referrer"
                    />
                    {participant.raisedHand && (
                      <span className="absolute -top-1 -right-1 bg-purple-500 text-white p-1 rounded-full shadow animate-bounce">
                        <Hand className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] font-medium text-slate-300 mt-1 truncate max-w-[70px] text-center">
                    {participant.user.displayName.split(' ')[0]}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* In-Room Chat Stream */}
        <div className="pt-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
              <span>Room Chat</span>
            </span>
            <button
              onClick={() => setShowChat((prev) => !prev)}
              className="text-[11px] text-purple-400 hover:text-purple-300"
            >
              {showChat ? 'Hide' : 'Show'}
            </button>
          </div>

          {showChat && (
            <div className="bg-slate-950/60 border border-slate-800/70 rounded-2xl p-3 h-36 flex flex-col">
              <div ref={chatScrollRef} className="flex-1 overflow-y-auto space-y-2 pr-1 text-xs">
                {roomChatMessages.length === 0 ? (
                  <p className="text-slate-500 text-center py-4 text-[11px]">
                    Welcome! Say hello to everyone in the room ✨
                  </p>
                ) : (
                  roomChatMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={msg.isSystem ? 'text-[11px] text-purple-300/80 italic text-center' : 'flex items-start gap-1.5'}
                    >
                      {!msg.isSystem && (
                        <span className="font-semibold text-purple-300 shrink-0">
                          {msg.sender.displayName}:
                        </span>
                      )}
                      <span className="text-slate-200">{msg.text}</span>
                    </div>
                  ))
                )}
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSendChat} className="mt-2 flex items-center gap-2 pt-2 border-t border-slate-800/80">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Say something to the room..."
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
                <button
                  type="submit"
                  disabled={!chatInput.trim()}
                  className="p-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white disabled:opacity-40 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}
        </div>
      </div>

      {/* Quick Reaction Bar */}
      <div className="px-4 py-2 bg-slate-950/90 border-t border-purple-950/40 flex items-center justify-between gap-1 overflow-x-auto shrink-0">
        <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider shrink-0 mr-1 hidden sm:inline">
          Reactions:
        </span>
        {['❤️', '🔥', '👏', '😂', '💎', '🚀', '🎙️'].map((emoji) => (
          <button
            key={emoji}
            onClick={() => sendReaction(emoji)}
            className="w-9 h-9 rounded-xl bg-slate-900/80 hover:bg-purple-900/30 active:scale-125 flex items-center justify-center text-lg transition-transform shrink-0"
          >
            {emoji}
          </button>
        ))}
        <button
          onClick={triggerConfettiParty}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs font-semibold shrink-0 shadow-md active:scale-95 transition-transform"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Party</span>
        </button>
      </div>

      {/* Bottom Stage Action Toolbar */}
      <div className="px-4 py-3 bg-[#070b14] border-t border-purple-900/30 flex items-center justify-around gap-2 shrink-0">
        {/* Mic Toggle or Hand Raise */}
        {isSpeakerOrHost ? (
          <button
            onClick={toggleMic}
            className={`flex-1 max-w-[160px] py-3 rounded-2xl flex items-center justify-center gap-2 font-semibold text-xs transition-all shadow-lg active:scale-95 ${
              isMuted
                ? 'bg-red-500/20 text-red-300 border border-red-500/40 hover:bg-red-500/30 shadow-red-950/50'
                : 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-emerald-950/50'
            }`}
          >
            {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            <span>{isMuted ? 'Muted' : 'Speaking'}</span>
          </button>
        ) : (
          <button
            onClick={toggleHandRaise}
            className={`flex-1 max-w-[160px] py-3 rounded-2xl flex items-center justify-center gap-2 font-semibold text-xs transition-all shadow-lg active:scale-95 ${
              raisedHand
                ? 'bg-purple-600 text-white ring-2 ring-purple-400 shadow-purple-950/50'
                : 'bg-slate-900 hover:bg-slate-800 text-purple-300 border border-purple-900/50'
            }`}
          >
            <Hand className="w-4 h-4" />
            <span>{raisedHand ? 'Hand Raised' : 'Request to Speak'}</span>
          </button>
        )}

        {/* Soundboard Button */}
        <button
          onClick={() => {
            audioEngine.playSoundEffect('applause');
            sendReaction('👏');
          }}
          className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-purple-900/30 text-purple-300 flex items-center justify-center transition-colors min-h-[44px] min-w-[44px]"
          title="Play applause sound effect"
        >
          <Volume2 className="w-5 h-5" />
        </button>

        {/* Leave Room Button */}
        <button
          onClick={leaveRoom}
          className="p-3 rounded-2xl bg-red-950/50 hover:bg-red-900/60 border border-red-900/40 text-red-300 flex items-center justify-center transition-colors min-h-[44px] min-w-[44px]"
          title="Leave voice room"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>

      {/* Host Participant Action Modal */}
      {selectedParticipant && isHost && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-purple-900/50 rounded-3xl p-5 shadow-2xl animate-in slide-in-from-bottom-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <img
                  src={selectedParticipant.user.avatar}
                  alt={selectedParticipant.user.displayName}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h4 className="text-sm font-bold text-white">{selectedParticipant.user.displayName}</h4>
                  <p className="text-xs text-slate-400">@{selectedParticipant.user.username}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedParticipantId(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-3 space-y-2">
              {selectedParticipant.role === 'listener' ? (
                <button
                  onClick={() => {
                    promoteToSpeaker(selectedParticipant.user.id);
                    setSelectedParticipantId(null);
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs flex items-center gap-2"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Promote to Speaker</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    demoteToListener(selectedParticipant.user.id);
                    setSelectedParticipantId(null);
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs flex items-center gap-2"
                >
                  <VolumeX className="w-4 h-4" />
                  <span>Move to Listeners</span>
                </button>
              )}

              <button
                onClick={() => {
                  muteParticipant(selectedParticipant.user.id);
                  setSelectedParticipantId(null);
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs flex items-center gap-2"
              >
                <MicOff className="w-4 h-4" />
                <span>Mute Participant</span>
              </button>

              <button
                onClick={() => {
                  kickParticipant(selectedParticipant.user.id);
                  setSelectedParticipantId(null);
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-red-950/60 hover:bg-red-900/60 text-red-300 font-medium text-xs flex items-center gap-2 border border-red-900/40"
              >
                <PhoneOff className="w-4 h-4" />
                <span>Remove from Room</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
