import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Radio, Plus, Lock, Globe, Volume2, Users, Sparkles } from 'lucide-react';
import { VoiceRoom } from '../../types';

export const RoomsView: React.FC = () => {
  const { rooms, joinRoom, setShowCreateRoomModal, activeRoom } = useApp();
  const [filterMode, setFilterMode] = useState<'all' | 'public' | 'private'>('all');
  const [pinInputRoom, setPinInputRoom] = useState<VoiceRoom | null>(null);
  const [enteredPin, setEnteredPin] = useState('');
  const [pinError, setPinError] = useState(false);

  const filtered = rooms.filter((r) => {
    if (filterMode === 'public') return !r.isPrivate;
    if (filterMode === 'private') return r.isPrivate;
    return true;
  });

  const handleJoinClick = (room: VoiceRoom) => {
    if (room.isPrivate) {
      setPinInputRoom(room);
      setEnteredPin('');
      setPinError(false);
    } else {
      joinRoom(room);
    }
  };

  const verifyPinAndJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinInputRoom) return;

    if (pinInputRoom.pinCode && enteredPin !== pinInputRoom.pinCode) {
      setPinError(true);
      return;
    }

    joinRoom(pinInputRoom);
    setPinInputRoom(null);
  };

  return (
    <div className="space-y-5 pb-24 pt-2">
      {/* Top Banner & Create Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-gradient-to-r from-purple-900/40 to-slate-900 border border-purple-800/30 rounded-2xl p-4 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-purple-400" />
            <h1 className="text-lg font-bold text-white font-display">Live Audio Hub</h1>
          </div>
          <p className="text-xs text-slate-300 mt-0.5">
            Real-time drop-in voice rooms with WebRTC audio and speaker stages
          </p>
        </div>

        <button
          onClick={() => setShowCreateRoomModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 text-white font-semibold text-xs shadow-md shadow-purple-900/40 transition-transform active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Host a Voice Room</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              filterMode === 'all'
                ? 'bg-purple-600 text-white'
                : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            All Rooms ({rooms.length})
          </button>
          <button
            onClick={() => setFilterMode('public')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              filterMode === 'public'
                ? 'bg-purple-600 text-white'
                : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            Public
          </button>
          <button
            onClick={() => setFilterMode('private')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              filterMode === 'private'
                ? 'bg-purple-600 text-white'
                : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            Private PIN
          </button>
        </div>

        <span className="text-[11px] text-purple-300/80 hidden sm:inline">
          {activeRoom ? `Currently in: ${activeRoom.title}` : 'Select a stage to join'}
        </span>
      </div>

      {/* Rooms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filtered.map((room) => {
          const isCurrentlyInThisRoom = activeRoom?.id === room.id;
          const speakers = room.participants.filter(
            (p) => p.role === 'host' || p.role === 'speaker'
          );

          return (
            <div
              key={room.id}
              onClick={() => handleJoinClick(room)}
              className={`bg-slate-900/70 hover:bg-slate-900 border rounded-2xl p-4 transition-all duration-200 cursor-pointer shadow-lg flex flex-col justify-between ${
                isCurrentlyInThisRoom
                  ? 'border-purple-500 shadow-purple-900/30 ring-1 ring-purple-500/50'
                  : 'border-slate-800 hover:border-purple-500/40'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-semibold text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded-md border border-purple-800/40">
                      {room.topic}
                    </span>
                    {room.isPrivate && (
                      <span className="text-[10px] text-amber-300 bg-amber-950/40 border border-amber-800/30 px-1.5 py-0.5 rounded flex items-center gap-1">
                        <Lock className="w-2.5 h-2.5" /> PIN
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <span>{room.flag}</span>
                    <span className="text-[11px]">{room.language}</span>
                  </div>
                </div>

                <h3 className="text-sm font-bold text-white line-clamp-1">{room.title}</h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">{room.description}</p>

                {/* Host & Speaker previews */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-2">
                      {speakers.map((s) => (
                        <div key={s.user.id} className="relative">
                          <img
                            src={s.user.avatar}
                            alt={s.user.displayName}
                            className="w-7 h-7 rounded-full object-cover border-2 border-slate-900 bg-slate-800"
                          />
                          {s.isSpeaking && (
                            <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-emerald-400 ring-1 ring-slate-900" />
                          )}
                        </div>
                      ))}
                    </div>
                    <span className="text-xs text-slate-300 font-medium truncate max-w-[140px]">
                      {room.host.displayName}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                    <Users className="w-3.5 h-3.5" />
                    <span>{room.totalParticipantsCount}</span>
                  </div>
                </div>
              </div>

              <div className="mt-3.5 pt-2 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-[11px] text-purple-300">
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>{speakers.length} on mic</span>
                </div>

                <button
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold shadow-md transition-colors ${
                    isCurrentlyInThisRoom
                      ? 'bg-emerald-600 text-white'
                      : 'bg-purple-600 hover:bg-purple-500 text-white'
                  }`}
                >
                  {isCurrentlyInThisRoom ? 'Joined' : 'Enter Room'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Private Room PIN Modal */}
      {pinInputRoom && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-purple-900/50 rounded-2xl p-5 shadow-2xl">
            <h3 className="text-sm font-bold text-white mb-1">Enter Room PIN</h3>
            <p className="text-xs text-slate-400 mb-4">
              "{pinInputRoom.title}" is a private room. Please enter the 4-digit code.
            </p>

            <form onSubmit={verifyPinAndJoin} className="space-y-3">
              <input
                type="password"
                maxLength={4}
                autoFocus
                value={enteredPin}
                onChange={(e) => {
                  setEnteredPin(e.target.value);
                  setPinError(false);
                }}
                placeholder="4-digit PIN"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-center text-sm font-mono tracking-widest text-white focus:outline-none focus:border-purple-500"
              />

              {pinError && (
                <p className="text-xs text-red-400 text-center">
                  Incorrect PIN code. Try demo code "1234".
                </p>
              )}

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPinInputRoom(null)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"
                >
                  Unlock & Join
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
