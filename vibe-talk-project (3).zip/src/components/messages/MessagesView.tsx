import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Search,
  Send,
  Image as ImageIcon,
  Smile,
  Mic,
  MoreVertical,
  ChevronLeft,
  ShieldAlert,
  Ban,
  CheckCheck,
  Check,
  X,
  Radio,
} from 'lucide-react';
import { User, DirectMessage } from '../../types';

export const MessagesView: React.FC = () => {
  const {
    conversations,
    activeChatUser,
    setActiveChatUser,
    sendDirectMessage,
    openUserProfile,
    blockUser,
    submitReport,
    friends,
    currentUser,
    joinRoom,
    rooms,
  } = useApp();

  const [messageText, setMessageText] = useState('');
  const [searchFilter, setSearchFilter] = useState('');
  const [showOptionsDropdown, setShowOptionsDropdown] = useState(false);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [reportModalUser, setReportModalUser] = useState<User | null>(null);
  const [reportReason, setReportReason] = useState<'Harassment or Bullying' | 'Hate Speech' | 'Inappropriate Audio / Nudity' | 'Spam or Scam' | 'Disruptive Audio Noise' | 'Underage User'>('Spam or Scam');
  const [reportNotes, setReportNotes] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Active conversation thread messages
  const activeConversation = conversations.find((c) => c.otherUser.id === activeChatUser?.id);

  // Scroll to bottom when conversation messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeConversation?.lastMessage.id, activeChatUser]);

  // Simulate typing indicator briefly after sending
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeChatUser) return;
    if (!messageText.trim() && !selectedImagePreview) return;

    sendDirectMessage(activeChatUser.id, messageText, selectedImagePreview || undefined);
    setMessageText('');
    setSelectedImagePreview(null);

    // Show simulated typing response indicator
    setTimeout(() => {
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
      }, 2000);
    }, 500);
  };

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const filteredConversations = conversations.filter((c) =>
    c.otherUser.displayName.toLowerCase().includes(searchFilter.toLowerCase()) ||
    c.otherUser.username.toLowerCase().includes(searchFilter.toLowerCase()) ||
    c.lastMessage.text.toLowerCase().includes(searchFilter.toLowerCase())
  );

  // Active chat view
  if (activeChatUser) {
    const formatTime = (ts: number) => {
      const date = new Date(ts);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    return (
      <div className="fixed inset-0 top-[53px] bottom-16 z-20 bg-[#070b14] flex flex-col">
        {/* Chat Header */}
        <div className="px-4 py-2.5 bg-slate-950/90 backdrop-blur-xl border-b border-purple-900/30 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              onClick={() => setActiveChatUser(null)}
              className="p-1.5 -ml-1 text-slate-400 hover:text-white rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <div
              onClick={() => openUserProfile(activeChatUser)}
              className="flex items-center gap-2.5 cursor-pointer min-w-0"
            >
              <div className="relative">
                <img
                  src={activeChatUser.avatar}
                  alt={activeChatUser.displayName}
                  className="w-9 h-9 rounded-full object-cover border border-purple-500/30 bg-slate-800"
                />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-slate-900" />
              </div>
              <div className="min-w-0">
                <h3 className="text-xs font-bold text-white truncate">
                  {activeChatUser.displayName}
                </h3>
                <p className="text-[10px] text-purple-300/80 truncate">
                  {activeChatUser.flag} {activeChatUser.country} · Native {activeChatUser.nativeLanguage}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 relative">
            <button
              onClick={() => setShowOptionsDropdown((prev) => !prev)}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {showOptionsDropdown && (
              <div className="absolute right-0 top-10 w-44 bg-slate-900 border border-purple-900/50 rounded-2xl shadow-2xl p-1.5 z-50 text-xs">
                <button
                  onClick={() => {
                    setShowOptionsDropdown(false);
                    openUserProfile(activeChatUser);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-slate-200"
                >
                  View Profile
                </button>
                <button
                  onClick={() => {
                    setShowOptionsDropdown(false);
                    setReportModalUser(activeChatUser);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-amber-300 flex items-center gap-1.5"
                >
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Report User</span>
                </button>
                <button
                  onClick={() => {
                    setShowOptionsDropdown(false);
                    if (confirm(`Are you sure you want to block ${activeChatUser.displayName}?`)) {
                      blockUser(activeChatUser.id);
                      setActiveChatUser(null);
                    }
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800 text-red-400 flex items-center gap-1.5"
                >
                  <Ban className="w-3.5 h-3.5" />
                  <span>Block User</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Message Bubble History */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
          {/* Welcome chat notice */}
          <div className="text-center py-4">
            <p className="text-[11px] text-slate-500">
              This is the beginning of your conversation with {activeChatUser.displayName}.
            </p>
            <p className="text-[10px] text-purple-400/80 mt-0.5">
              Encrypted end-to-end messaging · Adhere to community guidelines
            </p>
          </div>

          {/* Conversation history */}
          {activeConversation?.lastMessage && (
            <div
              className={`flex flex-col ${
                activeConversation.lastMessage.senderId === currentUser.id
                  ? 'items-end'
                  : 'items-start'
              }`}
            >
              <div
                className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 text-xs shadow-md ${
                  activeConversation.lastMessage.senderId === currentUser.id
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-br-xs'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-xs'
                }`}
              >
                {activeConversation.lastMessage.attachmentUrl && (
                  <img
                    src={activeConversation.lastMessage.attachmentUrl}
                    alt="attachment"
                    className="rounded-lg mb-2 max-h-48 w-full object-cover"
                  />
                )}
                <p className="leading-relaxed whitespace-pre-wrap">
                  {activeConversation.lastMessage.text}
                </p>
              </div>
              <div className="flex items-center gap-1 mt-1 text-[10px] text-slate-500 px-1">
                <span>{formatTime(activeConversation.lastMessage.timestamp)}</span>
                {activeConversation.lastMessage.senderId === currentUser.id && (
                  <CheckCheck className="w-3 h-3 text-cyan-400" />
                )}
              </div>
            </div>
          )}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-center gap-2 text-slate-400 text-xs py-1">
              <div className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center">
                <img
                  src={activeChatUser.avatar}
                  alt={activeChatUser.displayName}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="bg-slate-900 px-3 py-1.5 rounded-full flex items-center gap-1 border border-slate-800">
                <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" />
                <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce delay-100" />
                <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce delay-200" />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Image Attachment Preview */}
        {selectedImagePreview && (
          <div className="px-4 py-2 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
            <div className="relative">
              <img
                src={selectedImagePreview}
                alt="Upload preview"
                className="w-14 h-14 object-cover rounded-xl border border-purple-500/50"
              />
              <button
                onClick={() => setSelectedImagePreview(null)}
                className="absolute -top-1.5 -right-1.5 bg-red-600 text-white rounded-full p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <span className="text-xs text-slate-400">Ready to attach</span>
          </div>
        )}

        {/* Input Bar */}
        <form
          onSubmit={handleSendMessage}
          className="p-3 bg-slate-950/95 border-t border-purple-900/30 flex items-center gap-2 shrink-0"
        >
          <label className="p-2 rounded-xl text-slate-400 hover:text-purple-400 cursor-pointer transition-colors">
            <ImageIcon className="w-4 h-4" />
            <input
              type="file"
              accept="image/*"
              onChange={handleImagePick}
              className="hidden"
            />
          </label>

          <input
            type="text"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />

          <button
            type="submit"
            disabled={!messageText.trim() && !selectedImagePreview}
            className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* Report Dialog */}
        {reportModalUser && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-sm bg-slate-900 border border-purple-900/50 rounded-2xl p-5 shadow-2xl">
              <h3 className="text-sm font-bold text-white mb-1">
                Report {reportModalUser.displayName}
              </h3>
              <p className="text-xs text-slate-400 mb-3">
                Help keep the VIBE TALK community safe and friendly.
              </p>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Reason</label>
                  <select
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="Spam or Scam">Spam or Scam</option>
                    <option value="Harassment or Bullying">Harassment or Bullying</option>
                    <option value="Hate Speech">Hate Speech</option>
                    <option value="Inappropriate Audio / Nudity">Inappropriate Content</option>
                    <option value="Underage User">Underage User</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Details</label>
                  <textarea
                    rows={2}
                    value={reportNotes}
                    onChange={(e) => setReportNotes(e.target.value)}
                    placeholder="Provide additional details..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setReportModalUser(null)}
                    className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      submitReport(reportModalUser, reportReason, reportNotes);
                      setReportModalUser(null);
                    }}
                    className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold"
                  >
                    Submit Report
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Conversation list view
  return (
    <div className="space-y-4 pb-24 pt-2">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white font-display">Direct Messages</h1>
        <p className="text-xs text-slate-400">Chat with friends & language exchange partners</p>
      </div>

      {/* Active Friends Strip */}
      {friends.length > 0 && (
        <div className="space-y-2">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Online Friends ({friends.length})
          </span>
          <div className="flex items-center gap-3 overflow-x-auto pb-1 no-scrollbar">
            {friends.map((friend) => (
              <div
                key={friend.id}
                onClick={() => setActiveChatUser(friend)}
                className="flex flex-col items-center gap-1 cursor-pointer shrink-0 group"
              >
                <div className="relative">
                  <img
                    src={friend.avatar}
                    alt={friend.displayName}
                    className="w-12 h-12 rounded-full object-cover border border-purple-500/40 group-hover:border-purple-400 transition-colors"
                  />
                  <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#070b14]" />
                </div>
                <span className="text-[10px] text-slate-300 font-medium truncate max-w-[64px]">
                  {friend.displayName.split(' ')[0]}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchFilter}
          onChange={(e) => setSearchFilter(e.target.value)}
          placeholder="Search conversations..."
          className="w-full bg-slate-900 border border-slate-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
        />
      </div>

      {/* Conversations List */}
      <div className="space-y-2">
        {filteredConversations.length === 0 ? (
          <div className="text-center py-12 bg-slate-900/40 rounded-2xl border border-slate-800">
            <p className="text-xs text-slate-400">No conversations yet</p>
            <p className="text-[11px] text-slate-500 mt-1">
              Find partners on Discover or join a voice room to start talking!
            </p>
          </div>
        ) : (
          filteredConversations.map((conv) => {
            const timeAgo = new Date(conv.lastMessage.timestamp).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <div
                key={conv.id}
                onClick={() => setActiveChatUser(conv.otherUser)}
                className="bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-purple-500/40 rounded-2xl p-3.5 flex items-center justify-between gap-3 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      src={conv.otherUser.avatar}
                      alt={conv.otherUser.displayName}
                      className="w-12 h-12 rounded-full object-cover border border-purple-500/30 bg-slate-800"
                    />
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-900" />
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-white truncate">
                        {conv.otherUser.displayName}
                      </h4>
                      <span className="text-[11px]">{conv.otherUser.flag}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5 max-w-[200px] sm:max-w-md">
                      {conv.lastMessage.senderId === currentUser.id ? 'You: ' : ''}
                      {conv.lastMessage.text}
                    </p>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1 shrink-0">
                  <span className="text-[10px] text-slate-500">{timeAgo}</span>
                  {conv.unreadCount > 0 && (
                    <span className="min-w-[18px] h-4 px-1 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center">
                      {conv.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
