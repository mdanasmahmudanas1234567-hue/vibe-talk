import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, UserPlus, MessageCircle, ShieldAlert, Ban, Check, Heart, Volume2 } from 'lucide-react';
import { audioEngine } from '../../services/audioEngine';

export const UserProfileModal: React.FC = () => {
  const {
    selectedUserForModal,
    closeUserProfile,
    openChatWithUser,
    sendFriendRequest,
    friends,
    removeFriend,
    blockUser,
    submitReport,
    currentUser,
  } = useApp();

  const [hasRequested, setHasRequested] = useState(false);
  const [showReportForm, setShowReportForm] = useState(false);
  const [reportReason, setReportReason] = useState<'Harassment or Bullying' | 'Hate Speech' | 'Inappropriate Audio / Nudity' | 'Spam or Scam' | 'Disruptive Audio Noise' | 'Underage User'>('Harassment or Bullying');
  const [reportNotes, setReportNotes] = useState('');

  if (!selectedUserForModal) return null;

  const isMe = selectedUserForModal.id === currentUser.id;
  const isFriend = friends.some((f) => f.id === selectedUserForModal.id);

  const handleFriendClick = () => {
    if (isFriend) {
      removeFriend(selectedUserForModal.id);
    } else {
      sendFriendRequest(selectedUserForModal);
      setHasRequested(true);
    }
  };

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitReport(selectedUserForModal, reportReason, reportNotes);
    setShowReportForm(false);
    closeUserProfile();
  };

  const playChimeSample = () => {
    audioEngine.playChime(520, 0.25, 'sine');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-sm bg-slate-900 border border-purple-900/50 rounded-3xl p-5 shadow-2xl relative">
        <button
          onClick={closeUserProfile}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-xl bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {!showReportForm ? (
          <div>
            {/* Header info */}
            <div className="flex flex-col items-center text-center mt-2">
              <div className="relative">
                <img
                  src={selectedUserForModal.avatar}
                  alt={selectedUserForModal.displayName}
                  className="w-20 h-20 rounded-full object-cover border-2 border-purple-500/50 shadow-xl bg-slate-800"
                />
                <span className="absolute bottom-0 right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-slate-900" />
              </div>

              <div className="flex items-center gap-1.5 mt-2.5">
                <h3 className="text-base font-bold text-white font-display">
                  {selectedUserForModal.displayName}
                </h3>
                <span className="text-sm">{selectedUserForModal.flag}</span>
              </div>
              <p className="text-xs text-purple-300">@{selectedUserForModal.username}</p>

              <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                <span>{selectedUserForModal.country}</span>
                <span>·</span>
                <span className="text-emerald-400 font-medium">Reputation {selectedUserForModal.reputationScore}</span>
              </div>
            </div>

            {/* Bio */}
            <div className="mt-4 bg-slate-950/60 rounded-2xl p-3 border border-slate-800/80 text-left">
              <p className="text-xs text-slate-200 leading-relaxed">{selectedUserForModal.bio}</p>

              <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">Native:</span>
                  <span className="text-purple-300 font-semibold">{selectedUserForModal.nativeLanguage}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Learning:</span>
                  <span className="text-cyan-300 font-semibold truncate max-w-[170px]">
                    {selectedUserForModal.learningLanguages.join(', ')}
                  </span>
                </div>
              </div>
            </div>

            {/* Interests tags */}
            <div className="mt-3 flex flex-wrap gap-1">
              {selectedUserForModal.interests.map((interest) => (
                <span
                  key={interest}
                  className="px-2 py-0.5 rounded-md bg-slate-800 text-[10px] text-slate-300"
                >
                  {interest}
                </span>
              ))}
            </div>

            {/* Action buttons */}
            {!isMe && (
              <div className="mt-4 pt-3 border-t border-slate-800 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => openChatWithUser(selectedUserForModal)}
                    className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <MessageCircle className="w-4 h-4 text-cyan-400" />
                    <span>Message</span>
                  </button>

                  <button
                    onClick={handleFriendClick}
                    disabled={hasRequested}
                    className={`py-2.5 px-3 rounded-xl font-semibold text-xs flex items-center justify-center gap-1.5 transition-all ${
                      isFriend
                        ? 'bg-slate-800 text-red-300 hover:bg-red-950/40'
                        : hasRequested
                        ? 'bg-purple-950 text-purple-300'
                        : 'bg-purple-600 hover:bg-purple-500 text-white'
                    }`}
                  >
                    {isFriend ? (
                      <span>Remove Friend</span>
                    ) : hasRequested ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Sent</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Add Friend</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Safety & Moderation triggers */}
                <div className="flex items-center justify-between pt-1 text-[11px] text-slate-400">
                  <button
                    onClick={() => setShowReportForm(true)}
                    className="hover:text-amber-300 flex items-center gap-1"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                    <span>Report User</span>
                  </button>

                  <button
                    onClick={() => {
                      if (confirm(`Block @${selectedUserForModal.username}?`)) {
                        blockUser(selectedUserForModal.id);
                        closeUserProfile();
                      }
                    }}
                    className="hover:text-red-400 flex items-center gap-1"
                  >
                    <Ban className="w-3.5 h-3.5 text-red-400" />
                    <span>Block User</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Report Form */
          <form onSubmit={handleReportSubmit} className="space-y-3 mt-2">
            <h3 className="text-sm font-bold text-white">Report @{selectedUserForModal.username}</h3>
            <p className="text-xs text-slate-400">Select reason for moderation review:</p>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Violation Category</label>
              <select
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="Harassment or Bullying">Harassment or Bullying</option>
                <option value="Hate Speech">Hate Speech</option>
                <option value="Inappropriate Audio / Nudity">Inappropriate Content</option>
                <option value="Spam or Scam">Spam or Scam</option>
                <option value="Disruptive Audio Noise">Disruptive Audio Noise</option>
                <option value="Underage User">Underage User</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Details</label>
              <textarea
                rows={3}
                required
                value={reportNotes}
                onChange={(e) => setReportNotes(e.target.value)}
                placeholder="Explain what happened..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowReportForm(false)}
                className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
              >
                Back
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold"
              >
                Submit Report
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
