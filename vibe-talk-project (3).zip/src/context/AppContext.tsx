import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import {
  User,
  VoiceRoom,
  RoomParticipant,
  RoomChatMessage,
  DirectMessage,
  Conversation,
  FriendRequest,
  NotificationItem,
  ModerationReport,
  FloatingReaction,
} from '../types';
import {
  INITIAL_CURRENT_USER,
  MOCK_USERS,
  MOCK_ROOMS,
  MOCK_CONVERSATIONS,
  MOCK_NOTIFICATIONS,
  MOCK_REPORTS,
} from '../data/mockData';
import { audioEngine } from '../services/audioEngine';
import { isFirebaseConfigured, auth } from '../services/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';

type TabType = 'home' | 'discover' | 'rooms' | 'messages' | 'profile';

interface AppContextType {
  currentUser: User;
  isAuthenticated: boolean;
  isFirebaseMode: boolean;
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  // Rooms & Voice
  rooms: VoiceRoom[];
  activeRoom: VoiceRoom | null;
  isRoomMinimized: boolean;
  joinRoom: (room: VoiceRoom) => void;
  leaveRoom: () => void;
  toggleRoomMinimize: () => void;
  createRoom: (newRoomData: {
    title: string;
    topic: VoiceRoom['topic'];
    language: string;
    description: string;
    isPrivate: boolean;
    pinCode?: string;
  }) => VoiceRoom;
  closeRoom: (roomId: string) => void;
  // Mic & Audio
  isMuted: boolean;
  isRealMicActive: boolean;
  myMicVolume: number;
  toggleMic: () => Promise<void>;
  raisedHand: boolean;
  toggleHandRaise: () => void;
  // Room chat & reactions
  roomChatMessages: RoomChatMessage[];
  sendRoomChatMessage: (text: string) => void;
  floatingReactions: FloatingReaction[];
  sendReaction: (emoji: string) => void;
  // Host & Mod permissions
  promoteToSpeaker: (userId: string) => void;
  demoteToListener: (userId: string) => void;
  muteParticipant: (userId: string) => void;
  kickParticipant: (userId: string) => void;
  // Social & messaging
  users: User[];
  conversations: Conversation[];
  activeChatUser: User | null;
  setActiveChatUser: (user: User | null) => void;
  openChatWithUser: (user: User) => void;
  sendDirectMessage: (receiverId: string, text: string, attachmentUrl?: string) => void;
  // Friends
  friends: User[];
  friendRequests: FriendRequest[];
  sendFriendRequest: (user: User) => void;
  acceptFriendRequest: (requestId: string) => void;
  declineFriendRequest: (requestId: string) => void;
  removeFriend: (userId: string) => void;
  // Safety & Moderation
  blockedUserIds: string[];
  blockUser: (userId: string) => void;
  unblockUser: (userId: string) => void;
  reports: ModerationReport[];
  submitReport: (reportedUser: User, reason: ModerationReport['reason'], notes: string, roomId?: string, roomTitle?: string) => void;
  resolveReport: (reportId: string, actionTaken: string) => void;
  dismissReport: (reportId: string) => void;
  // Profile & User View Modal
  selectedUserForModal: User | null;
  openUserProfile: (user: User) => void;
  closeUserProfile: () => void;
  updateCurrentUserProfile: (updates: Partial<User>) => void;
  // Notifications
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  // UI Dialog States
  showAuthModal: boolean;
  setShowAuthModal: (open: boolean) => void;
  showCreateRoomModal: boolean;
  setShowCreateRoomModal: (open: boolean) => void;
  showAdminDashboard: boolean;
  setShowAdminDashboard: (open: boolean) => void;
  showAndroidGuide: boolean;
  setShowAndroidGuide: (open: boolean) => void;
  showBackendStatusModal: boolean;
  setShowBackendStatusModal: (open: boolean) => void;
  // Auth actions
  loginAsDemoUser: () => void;
  logout: () => void;
  deleteAccount: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Persistence state
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem('vibetalk_user');
    return saved ? JSON.parse(saved) : INITIAL_CURRENT_USER;
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem('vibetalk_auth');
    return saved ? JSON.parse(saved) : true; // starts logged in to Alex Rivers demo account for instant testability
  });

  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [rooms, setRooms] = useState<VoiceRoom[]>(MOCK_ROOMS);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [activeRoom, setActiveRoom] = useState<VoiceRoom | null>(null);
  const [isRoomMinimized, setIsRoomMinimized] = useState<boolean>(false);

  // Audio & Mic
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [isRealMicActive, setIsRealMicActive] = useState<boolean>(false);
  const [myMicVolume, setMyMicVolume] = useState<number>(0);
  const [raisedHand, setRaisedHand] = useState<boolean>(false);

  // Room Chat & Reactions
  const [roomChatMessages, setRoomChatMessages] = useState<RoomChatMessage[]>([]);
  const [floatingReactions, setFloatingReactions] = useState<FloatingReaction[]>([]);

  // Messages & Direct Chat
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    const saved = localStorage.getItem('vibetalk_convos');
    return saved ? JSON.parse(saved) : MOCK_CONVERSATIONS;
  });
  const [activeChatUser, setActiveChatUser] = useState<User | null>(null);

  // Friends & Requests
  const [friends, setFriends] = useState<User[]>(() => {
    return MOCK_USERS.filter((u) => u.isFriend);
  });
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([
    {
      id: 'req_clara',
      fromUser: MOCK_USERS[2],
      toUserId: INITIAL_CURRENT_USER.id,
      timestamp: Date.now() - 1000 * 60 * 60 * 2,
      status: 'pending',
    },
  ]);

  // Safety & Moderation
  const [blockedUserIds, setBlockedUserIds] = useState<string[]>([]);
  const [reports, setReports] = useState<ModerationReport[]>(MOCK_REPORTS);

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>(MOCK_NOTIFICATIONS);

  // Modals & Panels
  const [selectedUserForModal, setSelectedUserForModal] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [showCreateRoomModal, setShowCreateRoomModal] = useState<boolean>(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState<boolean>(false);
  const [showAndroidGuide, setShowAndroidGuide] = useState<boolean>(false);
  const [showBackendStatusModal, setShowBackendStatusModal] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('vibetalk_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('vibetalk_auth', JSON.stringify(isAuthenticated));
  }, [isAuthenticated]);

  useEffect(() => {
    localStorage.setItem('vibetalk_convos', JSON.stringify(conversations));
  }, [conversations]);

  // Firebase Auth listener if configured
  useEffect(() => {
    if (isFirebaseConfigured && auth) {
      const unsubscribe = onAuthStateChanged(auth, (fbUser) => {
        if (fbUser) {
          setIsAuthenticated(true);
          setCurrentUser((prev) => ({
            ...prev,
            id: fbUser.uid,
            displayName: fbUser.displayName || prev.displayName,
            avatar: fbUser.photoURL || prev.avatar,
          }));
        }
      });
      return () => unsubscribe();
    }
  }, []);

  // Simulated ambient speaker activity in the active room
  useEffect(() => {
    if (!activeRoom) return;

    const interval = setInterval(() => {
      // randomly toggle talking indicators on other participants for a lively feel
      setActiveRoom((prevRoom) => {
        if (!prevRoom) return null;
        const updatedParticipants = prevRoom.participants.map((p) => {
          if (p.user.id === currentUser.id) return p; // Don't fake current user's audio
          if (p.isMuted) return { ...p, isSpeaking: false, audioLevel: 0 };
          const willSpeak = Math.random() > 0.45;
          const level = willSpeak ? Math.floor(Math.random() * 65) + 35 : 0;
          return {
            ...p,
            isSpeaking: willSpeak,
            audioLevel: level,
          };
        });
        return {
          ...prevRoom,
          participants: updatedParticipants,
        };
      });
    }, 2800);

    return () => clearInterval(interval);
  }, [activeRoom?.id, currentUser.id]);

  // Join Room
  const joinRoom = useCallback(
    (room: VoiceRoom) => {
      audioEngine.playSoundEffect('pop');
      const isAlreadyIn = room.participants.some((p) => p.user.id === currentUser.id);
      let updatedParticipants = [...room.participants];

      if (!isAlreadyIn) {
        const newParticipant: RoomParticipant = {
          user: currentUser,
          role: room.hostId === currentUser.id ? 'host' : 'listener',
          isMuted: true,
          isSpeaking: false,
          raisedHand: false,
          joinedAt: Date.now(),
          audioLevel: 0,
        };
        updatedParticipants.push(newParticipant);
      }

      const joinedRoom: VoiceRoom = {
        ...room,
        participants: updatedParticipants,
        totalParticipantsCount: room.totalParticipantsCount + (isAlreadyIn ? 0 : 1),
      };

      setActiveRoom(joinedRoom);
      setIsRoomMinimized(false);
      setIsMuted(true);
      setRaisedHand(false);

      // System greeting message
      setRoomChatMessages([
        {
          id: `sys_${Date.now()}`,
          roomId: room.id,
          sender: currentUser,
          text: `${currentUser.displayName} hopped into the voice stage ✨`,
          timestamp: Date.now(),
          isSystem: true,
        },
      ]);
    },
    [currentUser]
  );

  // Leave Room
  const leaveRoom = useCallback(() => {
    audioEngine.playSoundEffect('ding');
    audioEngine.stopMicrophone();
    setIsRealMicActive(false);
    setIsMuted(true);
    setMyMicVolume(0);
    setRaisedHand(false);
    setActiveRoom(null);
    setIsRoomMinimized(false);
    setRoomChatMessages([]);
    setFloatingReactions([]);
  }, []);

  const toggleRoomMinimize = useCallback(() => {
    setIsRoomMinimized((prev) => !prev);
  }, []);

  // Create Room
  const createRoom = useCallback(
    (data: {
      title: string;
      topic: VoiceRoom['topic'];
      language: string;
      description: string;
      isPrivate: boolean;
      pinCode?: string;
    }): VoiceRoom => {
      const newRoom: VoiceRoom = {
        id: `room_${Date.now()}`,
        title: data.title,
        topic: data.topic,
        language: data.language,
        flag: '🎙️',
        description: data.description,
        isPrivate: data.isPrivate,
        pinCode: data.pinCode,
        hostId: currentUser.id,
        host: currentUser,
        maxSpeakers: 6,
        totalParticipantsCount: 1,
        createdAt: Date.now(),
        tags: [data.topic, data.language.split(' ')[0], 'Live Vibe'],
        participants: [
          {
            user: currentUser,
            role: 'host',
            isMuted: false,
            isSpeaking: false,
            raisedHand: false,
            joinedAt: Date.now(),
            audioLevel: 0,
          },
        ],
      };

      setRooms((prev) => [newRoom, ...prev]);
      joinRoom(newRoom);
      return newRoom;
    },
    [currentUser, joinRoom]
  );

  const closeRoom = useCallback(
    (roomId: string) => {
      audioEngine.playSoundEffect('ding');
      setRooms((prev) => prev.filter((r) => r.id !== roomId));
      if (activeRoom?.id === roomId) {
        leaveRoom();
      }
    },
    [activeRoom?.id, leaveRoom]
  );

  // Toggle Microphone
  const toggleMic = useCallback(async () => {
    if (!activeRoom) return;

    // Check participant role: listeners cannot speak unless promoted
    const myParticipant = activeRoom.participants.find((p) => p.user.id === currentUser.id);
    if (myParticipant && myParticipant.role === 'listener') {
      audioEngine.playSoundEffect('ding');
      alert('You are currently a listener. Tap the Hand button to request speaking permission from the host!');
      return;
    }

    audioEngine.playSoundEffect('mic_toggle');

    if (!isMuted) {
      // Mute
      audioEngine.stopMicrophone();
      setIsRealMicActive(false);
      setIsMuted(true);
      setMyMicVolume(0);

      // update activeRoom state
      setActiveRoom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          participants: prev.participants.map((p) =>
            p.user.id === currentUser.id
              ? { ...p, isMuted: true, isSpeaking: false, audioLevel: 0 }
              : p
          ),
        };
      });
    } else {
      // Unmute: attempt real mic capture
      const success = await audioEngine.startMicrophone((vol) => {
        setMyMicVolume(vol);
        setActiveRoom((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            participants: prev.participants.map((p) =>
              p.user.id === currentUser.id
                ? { ...p, isSpeaking: vol > 15, audioLevel: vol }
                : p
            ),
          };
        });
      });

      setIsMuted(false);
      setIsRealMicActive(success);

      setActiveRoom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          participants: prev.participants.map((p) =>
            p.user.id === currentUser.id
              ? { ...p, isMuted: false, isSpeaking: false }
              : p
          ),
        };
      });
    }
  }, [activeRoom, currentUser.id, isMuted]);

  // Hand Raise
  const toggleHandRaise = useCallback(() => {
    if (!activeRoom) return;
    audioEngine.playSoundEffect('pop');
    setRaisedHand((prev) => !prev);

    setActiveRoom((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        participants: prev.participants.map((p) =>
          p.user.id === currentUser.id ? { ...p, raisedHand: !p.raisedHand } : p
        ),
      };
    });
  }, [activeRoom, currentUser.id]);

  // Room Chat
  const sendRoomChatMessage = useCallback(
    (text: string) => {
      if (!activeRoom || !text.trim()) return;
      audioEngine.playSoundEffect('pop');
      const newMsg: RoomChatMessage = {
        id: `msg_${Date.now()}`,
        roomId: activeRoom.id,
        sender: currentUser,
        text: text.trim(),
        timestamp: Date.now(),
      };
      setRoomChatMessages((prev) => [...prev, newMsg]);
    },
    [activeRoom, currentUser]
  );

  // Floating Reactions
  const sendReaction = useCallback(
    (emoji: string) => {
      if (!activeRoom) return;
      audioEngine.playSoundEffect(emoji === '❤️' ? 'heart' : 'pop');

      const reaction: FloatingReaction = {
        id: `reaction_${Date.now()}_${Math.random()}`,
        emoji,
        x: Math.floor(Math.random() * 70) + 15,
        senderName: currentUser.displayName,
      };

      setFloatingReactions((prev) => [...prev, reaction]);

      // Remove reaction after animation completes
      setTimeout(() => {
        setFloatingReactions((prev) => prev.filter((r) => r.id !== reaction.id));
      }, 2300);
    },
    [activeRoom, currentUser.displayName]
  );

  // Host Controls
  const promoteToSpeaker = useCallback(
    (userId: string) => {
      if (!activeRoom) return;
      audioEngine.playSoundEffect('ding');
      setActiveRoom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          participants: prev.participants.map((p) =>
            p.user.id === userId ? { ...p, role: 'speaker', raisedHand: false, isMuted: false } : p
          ),
        };
      });
    },
    [activeRoom]
  );

  const demoteToListener = useCallback(
    (userId: string) => {
      if (!activeRoom) return;
      audioEngine.playSoundEffect('ding');
      setActiveRoom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          participants: prev.participants.map((p) =>
            p.user.id === userId
              ? { ...p, role: 'listener', isMuted: true, isSpeaking: false, audioLevel: 0 }
              : p
          ),
        };
      });
    },
    [activeRoom]
  );

  const muteParticipant = useCallback(
    (userId: string) => {
      if (!activeRoom) return;
      audioEngine.playSoundEffect('mic_toggle');
      setActiveRoom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          participants: prev.participants.map((p) =>
            p.user.id === userId
              ? { ...p, isMuted: true, isSpeaking: false, audioLevel: 0 }
              : p
          ),
        };
      });
    },
    [activeRoom]
  );

  const kickParticipant = useCallback(
    (userId: string) => {
      if (!activeRoom) return;
      audioEngine.playSoundEffect('ding');
      setActiveRoom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          participants: prev.participants.filter((p) => p.user.id !== userId),
          totalParticipantsCount: Math.max(1, prev.totalParticipantsCount - 1),
        };
      });
    },
    [activeRoom]
  );

  // Direct Messaging
  const openChatWithUser = useCallback((user: User) => {
    setActiveChatUser(user);
    setCurrentTab('messages');
    if (selectedUserForModal) {
      setSelectedUserForModal(null);
    }
  }, [selectedUserForModal]);

  const sendDirectMessage = useCallback(
    (receiverId: string, text: string, attachmentUrl?: string) => {
      if (!text.trim() && !attachmentUrl) return;
      audioEngine.playSoundEffect('pop');

      const targetUser = users.find((u) => u.id === receiverId) || activeChatUser;
      if (!targetUser) return;

      const newMsg: DirectMessage = {
        id: `dm_${Date.now()}`,
        conversationId: `conv_${receiverId}`,
        senderId: currentUser.id,
        receiverId,
        text: text.trim(),
        timestamp: Date.now(),
        isRead: true,
        attachmentUrl,
      };

      setConversations((prev) => {
        const existingIndex = prev.findIndex((c) => c.otherUser.id === receiverId);
        if (existingIndex >= 0) {
          const updated = [...prev];
          updated[existingIndex] = {
            ...updated[existingIndex],
            lastMessage: newMsg,
            updatedAt: Date.now(),
          };
          // Move to top
          const [moved] = updated.splice(existingIndex, 1);
          return [moved, ...updated];
        } else {
          const newConv: Conversation = {
            id: `conv_${receiverId}`,
            otherUser: targetUser,
            lastMessage: newMsg,
            unreadCount: 0,
            updatedAt: Date.now(),
          };
          return [newConv, ...prev];
        }
      });

      // Simulate a friendly conversational reply after 2.5 seconds
      setTimeout(() => {
        const replyPool = [
          "That's so cool! How long have you been studying?",
          'Totally agree! Let us jump in a voice room later tonight.',
          'Love your vibe! Catch you around the language lounge 😊',
          'Arigato! Thanks for sharing that with me!',
          'Hey Alex! Good to hear from you. Have a great day!',
        ];
        const randomReply = replyPool[Math.floor(Math.random() * replyPool.length)];
        const replyMsg: DirectMessage = {
          id: `dm_${Date.now() + 1}`,
          conversationId: `conv_${receiverId}`,
          senderId: receiverId,
          receiverId: currentUser.id,
          text: randomReply,
          timestamp: Date.now(),
          isRead: false,
        };

        setConversations((prev) => {
          const idx = prev.findIndex((c) => c.otherUser.id === receiverId);
          if (idx >= 0) {
            const updated = [...prev];
            updated[idx] = {
              ...updated[idx],
              lastMessage: replyMsg,
              unreadCount: updated[idx].unreadCount + 1,
              updatedAt: Date.now(),
            };
            return updated;
          }
          return prev;
        });

        audioEngine.playSoundEffect('ding');
      }, 2500);
    },
    [activeChatUser, currentUser.id, users]
  );

  // Friends management
  const sendFriendRequest = useCallback(
    (user: User) => {
      audioEngine.playSoundEffect('ding');
      setNotifications((prev) => [
        {
          id: `notif_${Date.now()}`,
          type: 'system',
          title: 'Friend Request Sent',
          message: `You sent a friend request to ${user.displayName} (@${user.username})`,
          timestamp: Date.now(),
          isRead: false,
        },
        ...prev,
      ]);
    },
    []
  );

  const acceptFriendRequest = useCallback(
    (requestId: string) => {
      audioEngine.playSoundEffect('applause');
      const req = friendRequests.find((r) => r.id === requestId);
      if (req) {
        setFriends((prev) => [...prev, req.fromUser]);
        setFriendRequests((prev) => prev.filter((r) => r.id !== requestId));
        setNotifications((prev) => [
          {
            id: `notif_${Date.now()}`,
            type: 'friend_request',
            title: 'New Friend Added',
            message: `You and ${req.fromUser.displayName} are now friends!`,
            timestamp: Date.now(),
            isRead: false,
            sender: req.fromUser,
          },
          ...prev,
        ]);
      }
    },
    [friendRequests]
  );

  const declineFriendRequest = useCallback((requestId: string) => {
    setFriendRequests((prev) => prev.filter((r) => r.id !== requestId));
  }, []);

  const removeFriend = useCallback((userId: string) => {
    setFriends((prev) => prev.filter((f) => f.id !== userId));
  }, []);

  // Safety & Blocking
  const blockUser = useCallback(
    (userId: string) => {
      audioEngine.playSoundEffect('ding');
      setBlockedUserIds((prev) => (prev.includes(userId) ? prev : [...prev, userId]));
      setFriends((prev) => prev.filter((f) => f.id !== userId));
      if (selectedUserForModal) {
        setSelectedUserForModal(null);
      }
    },
    [selectedUserForModal]
  );

  const unblockUser = useCallback((userId: string) => {
    setBlockedUserIds((prev) => prev.filter((id) => id !== userId));
  }, []);

  // Moderation Reporting
  const submitReport = useCallback(
    (
      reportedUser: User,
      reason: ModerationReport['reason'],
      notes: string,
      roomId?: string,
      roomTitle?: string
    ) => {
      audioEngine.playSoundEffect('ding');
      const newReport: ModerationReport = {
        id: `rep_${Date.now()}`,
        reportedUserId: reportedUser.id,
        reportedUser,
        reporterUserId: currentUser.id,
        reporterUser: currentUser,
        reason,
        notes: notes.trim(),
        roomId,
        roomTitle,
        timestamp: Date.now(),
        status: 'pending',
      };
      setReports((prev) => [newReport, ...prev]);

      setNotifications((prev) => [
        {
          id: `notif_${Date.now()}`,
          type: 'system',
          title: 'Report Received',
          message: `Your report regarding @${reportedUser.username} has been submitted to the moderation team. Thank you for keeping VIBE TALK safe!`,
          timestamp: Date.now(),
          isRead: false,
        },
        ...prev,
      ]);
    },
    [currentUser]
  );

  const resolveReport = useCallback((reportId: string, actionTaken: string) => {
    setReports((prev) =>
      prev.map((r) => (r.id === reportId ? { ...r, status: 'actioned', actionTaken } : r))
    );
  }, []);

  const dismissReport = useCallback((reportId: string) => {
    setReports((prev) =>
      prev.map((r) => (r.id === reportId ? { ...r, status: 'dismissed', actionTaken: 'Dismissed after review' } : r))
    );
  }, []);

  // Profile Modal
  const openUserProfile = useCallback((user: User) => {
    setSelectedUserForModal(user);
  }, []);

  const closeUserProfile = useCallback(() => {
    setSelectedUserForModal(null);
  }, []);

  const updateCurrentUserProfile = useCallback((updates: Partial<User>) => {
    setCurrentUser((prev) => ({ ...prev, ...updates }));
  }, []);

  // Notifications
  const markNotificationRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  }, []);

  const unreadNotificationCount = notifications.filter((n) => !n.isRead).length;

  // Auth
  const loginAsDemoUser = useCallback(() => {
    setCurrentUser(INITIAL_CURRENT_USER);
    setIsAuthenticated(true);
    setShowAuthModal(false);
  }, []);

  const logout = useCallback(() => {
    if (isFirebaseConfigured && auth) {
      signOut(auth).catch(console.error);
    }
    setIsAuthenticated(false);
    leaveRoom();
  }, [leaveRoom]);

  const deleteAccount = useCallback(() => {
    if (confirm('Are you sure you want to permanently delete your account and all associated data? This action cannot be undone.')) {
      localStorage.clear();
      setIsAuthenticated(false);
      setCurrentUser(INITIAL_CURRENT_USER);
      leaveRoom();
      alert('Your account and stored data have been permanently erased.');
    }
  }, [leaveRoom]);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        isFirebaseMode: isFirebaseConfigured,
        currentTab,
        setCurrentTab,
        rooms,
        activeRoom,
        isRoomMinimized,
        joinRoom,
        leaveRoom,
        toggleRoomMinimize,
        createRoom,
        closeRoom,
        isMuted,
        isRealMicActive,
        myMicVolume,
        toggleMic,
        raisedHand,
        toggleHandRaise,
        roomChatMessages,
        sendRoomChatMessage,
        floatingReactions,
        sendReaction,
        promoteToSpeaker,
        demoteToListener,
        muteParticipant,
        kickParticipant,
        users,
        conversations,
        activeChatUser,
        setActiveChatUser,
        openChatWithUser,
        sendDirectMessage,
        friends,
        friendRequests,
        sendFriendRequest,
        acceptFriendRequest,
        declineFriendRequest,
        removeFriend,
        blockedUserIds,
        blockUser,
        unblockUser,
        reports,
        submitReport,
        resolveReport,
        dismissReport,
        selectedUserForModal,
        openUserProfile,
        closeUserProfile,
        updateCurrentUserProfile,
        notifications,
        unreadNotificationCount,
        markNotificationRead,
        markAllNotificationsRead,
        showAuthModal,
        setShowAuthModal,
        showCreateRoomModal,
        setShowCreateRoomModal,
        showAdminDashboard,
        setShowAdminDashboard,
        showAndroidGuide,
        setShowAndroidGuide,
        showBackendStatusModal,
        setShowBackendStatusModal,
        loginAsDemoUser,
        logout,
        deleteAccount,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
