import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { TopHeader } from './components/layout/TopHeader';
import { BottomNav } from './components/layout/BottomNav';
import { HomeView } from './components/home/HomeView';
import { DiscoverView } from './components/discover/DiscoverView';
import { RoomsView } from './components/rooms/RoomsView';
import { MessagesView } from './components/messages/MessagesView';
import { ProfileView } from './components/profile/ProfileView';
import { ActiveRoomStage } from './components/rooms/ActiveRoomStage';
import { MiniPlayer } from './components/rooms/MiniPlayer';
import { CreateRoomModal } from './components/rooms/CreateRoomModal';
import { AuthModal } from './components/auth/AuthModal';
import { UserProfileModal } from './components/common/UserProfileModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AndroidExportGuide } from './components/android/AndroidExportGuide';
import { BackendStatusModal } from './components/backend/BackendStatusModal';

const MainLayout: React.FC = () => {
  const { currentTab } = useApp();

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-purple-600/30 selection:text-purple-200">
      {/* Top Header Navigation */}
      <TopHeader />

      {/* Main Content Area: Responsive container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-3.5 sm:px-6 pt-3">
        {currentTab === 'home' && <HomeView />}
        {currentTab === 'discover' && <DiscoverView />}
        {currentTab === 'rooms' && <RoomsView />}
        {currentTab === 'messages' && <MessagesView />}
        {currentTab === 'profile' && <ProfileView />}
      </main>

      {/* Floating MiniPlayer when room is active & minimized */}
      <MiniPlayer />

      {/* Mobile Fixed Bottom Navigation */}
      <BottomNav />

      {/* Full Screen Live Voice Stage */}
      <ActiveRoomStage />

      {/* Dialogs and Modals */}
      <CreateRoomModal />
      <AuthModal />
      <UserProfileModal />
      <AdminDashboard />
      <AndroidExportGuide />
      <BackendStatusModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
