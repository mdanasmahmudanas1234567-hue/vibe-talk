/**
 * Audio Engine for VIBE TALK
 * Handles Web Audio API synthesized soundboard effects,
 * real microphone capture & frequency analysis,
 * and audio reactivity for speaker avatar indicators.
 */

class AudioEngine {
  private audioCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private analyser: AnalyserNode | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private animFrameId: number | null = null;
  private isListeningToMic: boolean = false;
  private currentVolumeCallback: ((volume: number) => void) | null = null;

  private getAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Start capturing the real microphone to analyze live speaking volume
   */
  async startMicrophone(onVolumeChange: (volume: number) => void): Promise<boolean> {
    try {
      this.currentVolumeCallback = onVolumeChange;
      const ctx = this.getAudioContext();

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        console.warn('Microphone API not supported on this browser/environment');
        return false;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      this.micStream = stream;
      this.micSource = ctx.createMediaStreamSource(stream);
      this.analyser = ctx.createAnalyser();
      this.analyser.fftSize = 256;
      this.micSource.connect(this.analyser);
      this.isListeningToMic = true;

      const bufferLength = this.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const checkVolume = () => {
        if (!this.isListeningToMic || !this.analyser) return;

        this.analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const average = sum / bufferLength;
        // Normalize roughly to 0 - 100
        const normalized = Math.min(100, Math.round((average / 128) * 100));

        if (this.currentVolumeCallback) {
          this.currentVolumeCallback(normalized);
        }

        this.animFrameId = requestAnimationFrame(checkVolume);
      };

      checkVolume();
      this.playChime(520, 0.15, 'sine');
      return true;
    } catch (err) {
      console.warn('Microphone permission denied or not available:', err);
      return false;
    }
  }

  /**
   * Stop capturing real microphone
   */
  stopMicrophone(): void {
    this.isListeningToMic = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
    if (this.micSource) {
      this.micSource.disconnect();
      this.micSource = null;
    }
    this.analyser = null;
    if (this.currentVolumeCallback) {
      this.currentVolumeCallback(0);
      this.currentVolumeCallback = null;
    }
  }

  /**
   * Play clean synthesized chime sound
   */
  playChime(freq = 600, duration = 0.2, type: OscillatorType = 'sine'): void {
    try {
      const ctx = this.getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.5, ctx.currentTime + duration);

      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      console.warn('Sound play prevented:', e);
    }
  }

  /**
   * Room reactions soundboard: Applause, Ding, Heart sound, etc.
   */
  playSoundEffect(effect: 'applause' | 'cheer' | 'ding' | 'heart' | 'mic_toggle' | 'pop'): void {
    try {
      const ctx = this.getAudioContext();
      const now = ctx.currentTime;

      if (effect === 'ding' || effect === 'pop') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(effect === 'ding' ? 880 : 440, now);
        osc.frequency.exponentialRampToValueAtTime(effect === 'ding' ? 1320 : 880, now + 0.15);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(now + 0.15);
      } else if (effect === 'mic_toggle') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.setValueAtTime(440, now + 0.08);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(now + 0.16);
      } else if (effect === 'heart') {
        // Double thud like heartbeat
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(90, now);
        osc.frequency.exponentialRampToValueAtTime(45, now + 0.1);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(now + 0.1);

        setTimeout(() => {
          try {
            const osc2 = ctx.createOscillator();
            const gain2 = ctx.createGain();
            osc2.type = 'sine';
            const now2 = ctx.currentTime;
            osc2.frequency.setValueAtTime(85, now2);
            osc2.frequency.exponentialRampToValueAtTime(40, now2 + 0.1);
            gain2.gain.setValueAtTime(0.18, now2);
            gain2.gain.exponentialRampToValueAtTime(0.001, now2 + 0.1);
            osc2.connect(gain2);
            gain2.connect(ctx.destination);
            osc2.start();
            osc2.stop(now2 + 0.1);
          } catch {
            // Ignore
          }
        }, 120);
      } else if (effect === 'applause' || effect === 'cheer') {
        // Synthesize white noise bursts for cheering/clapping
        const bufferSize = ctx.sampleRate * 0.8;
        const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = Math.random() * 2 - 1;
        }

        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;

        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = effect === 'cheer' ? 1200 : 800;
        filter.Q.value = 1.8;

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

        whiteNoise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        whiteNoise.start();
        whiteNoise.stop(now + 0.8);
      }
    } catch (e) {
      console.warn('Audio effect playback issue:', e);
    }
  }
}

export const audioEngine = new AudioEngine();
