import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getAuth, Auth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';

// Default public demonstration configuration or injected environment variables
export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
};

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey &&
  firebaseConfig.projectId &&
  firebaseConfig.apiKey !== 'YOUR_API_KEY'
);

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
let googleProvider: GoogleAuthProvider | null = null;

if (isFirebaseConfigured) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
    auth = getAuth(app);
    db = getFirestore(app);
    googleProvider = new GoogleAuthProvider();
  } catch (error) {
    console.warn('Firebase initialization note (using local demo storage):', error);
  }
}

export { app, auth, db, googleProvider };

/**
 * Service connection diagnostics
 */
export interface ServiceStatus {
  firebaseConnected: boolean;
  livekitConnected: boolean;
  livekitUrl: string;
  storageMode: 'firebase_cloud' | 'local_storage_demo';
  audioMode: 'webrtc_livekit' | 'web_audio_local_mesh';
}

export const getServiceStatus = (): ServiceStatus => {
  const livekitUrl = import.meta.env.VITE_LIVEKIT_URL || '';
  const hasLivekit = Boolean(livekitUrl && livekitUrl.startsWith('wss://'));

  return {
    firebaseConnected: isFirebaseConfigured,
    livekitConnected: hasLivekit,
    livekitUrl: hasLivekit ? livekitUrl : 'Not configured (Operating in browser WebRTC / Web Audio mesh)',
    storageMode: isFirebaseConfigured ? 'firebase_cloud' : 'local_storage_demo',
    audioMode: hasLivekit ? 'webrtc_livekit' : 'web_audio_local_mesh',
  };
};
