export type UserRole = 'host' | 'moderator' | 'speaker' | 'listener';

export type UserStatus = 'online' | 'in_room' | 'offline';

export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  country: string;
  countryCode: string; // ISO 2-letter
  flag: string;
  nativeLanguage: string;
  learningLanguages: string[];
  interests: string[];
  status: UserStatus;
  followersCount: number;
  followingCount: number;
  isFriend?: boolean;
  isBlocked?: boolean;
  role?: 'user' | 'admin';
  joinedDate: string;
  reputationScore: number;
}

export interface RoomParticipant {
  user: User;
  role: UserRole;
  isMuted: boolean;
  isSpeaking: boolean;
  raisedHand: boolean;
  joinedAt: number;
  audioLevel?: number; // 0 to 100
}

export interface VoiceRoom {
  id: string;
  title: string;
  topic: 'Language Exchange' | 'Music & Chill' | 'Late Night Vibes' | 'Deep Talks' | 'Gaming' | 'Tech & Startups' | 'Culture & Travel' | 'General';
  language: string;
  flag: string;
  coverImage?: string;
  isPrivate: boolean;
  pinCode?: string;
  hostId: string;
  host: User;
  participants: RoomParticipant[];
  maxSpeakers: number;
  totalParticipantsCount: number;
  createdAt: number;
  tags: string[];
  description: string;
}

export interface RoomChatMessage {
  id: string;
  roomId: string;
  sender: User;
  text: string;
  timestamp: number;
  isSystem?: boolean;
}

export interface DirectMessage {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: number;
  isRead: boolean;
  attachmentUrl?: string;
  voiceNoteDuration?: number; // in seconds
}

export interface Conversation {
  id: string;
  otherUser: User;
  lastMessage: DirectMessage;
  unreadCount: number;
  updatedAt: number;
}

export interface FriendRequest {
  id: string;
  fromUser: User;
  toUserId: string;
  timestamp: number;
  status: 'pending' | 'accepted' | 'declined';
}

export interface NotificationItem {
  id: string;
  type: 'friend_request' | 'room_invite' | 'message' | 'system' | 'speaking_granted';
  title: string;
  message: string;
  timestamp: number;
  isRead: boolean;
  actionUrl?: string;
  sender?: User;
}

export interface ModerationReport {
  id: string;
  reportedUserId: string;
  reportedUser: User;
  reporterUserId: string;
  reporterUser: User;
  reason: 'Harassment or Bullying' | 'Hate Speech' | 'Inappropriate Audio / Nudity' | 'Spam or Scam' | 'Disruptive Audio Noise' | 'Underage User';
  notes: string;
  roomId?: string;
  roomTitle?: string;
  timestamp: number;
  status: 'pending' | 'actioned' | 'dismissed';
  actionTaken?: string;
}

export interface FloatingReaction {
  id: string;
  emoji: string;
  x: number; // percentage across screen 10-90
  senderName: string;
}
